package com.fitcoachai.presentation.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

/**
 * Shape tokens — rounded, modern, consistent with fitness app aesthetic.
 *
 * extraSmall : chips, badges, small buttons
 * small      : inputs, small cards
 * medium     : main cards, dialogs
 * large      : bottom sheets, hero cards
 * extraLarge : full-bleed panels
 */
val FitCoachShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small      = RoundedCornerShape(12.dp),
    medium     = RoundedCornerShape(16.dp),
    large      = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)
