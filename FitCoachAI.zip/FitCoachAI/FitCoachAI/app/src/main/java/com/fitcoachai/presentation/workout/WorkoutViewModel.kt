package com.fitcoachai.presentation.workout

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fitcoachai.core.data.repository.WorkoutRepository
import com.fitcoachai.core.utils.Result
import com.fitcoachai.domain.model.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.util.UUID
import javax.inject.Inject

// ─── Active Session State ─────────────────────────────────────────────────────

data class WorkoutSessionUiState(
    val workout: Workout? = null,
    val currentExerciseIndex: Int = 0,
    val currentSetIndex: Int = 0,
    val isRestTimerActive: Boolean = false,
    val restTimeRemainingSeconds: Int = 0,
    val totalRestSeconds: Int = 60,
    val isWorkoutComplete: Boolean = false,
    val elapsedSeconds: Int = 0,
    val isLoading: Boolean = false,
    val error: String? = null
)

// ─── Workout List State ───────────────────────────────────────────────────────

data class WorkoutListUiState(
    val templates: List<Workout> = emptyList(),
    val completed: List<Workout> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null
)

// ─── Workout Builder State ────────────────────────────────────────────────────

data class WorkoutBuilderUiState(
    val workout: Workout = Workout(
        id        = UUID.randomUUID().toString(),
        name      = "",
        exercises = emptyList()
    ),
    val isSaving: Boolean = false,
    val savedSuccessfully: Boolean = false,
    val error: String? = null
)

// ─── ViewModel ────────────────────────────────────────────────────────────────

@HiltViewModel
class WorkoutViewModel @Inject constructor(
    private val workoutRepository: WorkoutRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    // Optional: workoutId passed via navigation for editing an existing workout
    private val workoutId: String? = savedStateHandle.get<String>("workoutId")

    // ── List state ─────────────────────────────────────────────────────────────
    val listUiState: StateFlow<WorkoutListUiState> = combine(
        workoutRepository.observeTemplates(),
        workoutRepository.observeCompletedWorkouts()
    ) { templates, completed ->
        WorkoutListUiState(templates = templates, completed = completed, isLoading = false)
    }.catch { e ->
        emit(WorkoutListUiState(isLoading = false, error = e.message))
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), WorkoutListUiState())

    // ── Builder state ──────────────────────────────────────────────────────────
    private val _builderState = MutableStateFlow(WorkoutBuilderUiState())
    val builderState: StateFlow<WorkoutBuilderUiState> = _builderState.asStateFlow()

    // ── Session state ──────────────────────────────────────────────────────────
    private val _sessionState = MutableStateFlow(WorkoutSessionUiState())
    val sessionState: StateFlow<WorkoutSessionUiState> = _sessionState.asStateFlow()

    private var restTimerJob: Job? = null
    private var stopwatchJob: Job? = null

    init {
        workoutId?.let { loadWorkoutForEdit(it) }
    }

    // ── Builder Actions ────────────────────────────────────────────────────────

    fun onWorkoutNameChange(name: String) =
        _builderState.update { it.copy(workout = it.workout.copy(name = name)) }

    /**
     * Add an exercise to the current workout being built.
     * Initializes it with 3 default sets at 8 reps.
     */
    fun addExercise(exercise: Exercise) {
        val defaultSets = (1..3).map { SetEntry(setNumber = it, targetReps = 8) }
        val we = WorkoutExercise(exercise = exercise, sets = defaultSets)
        _builderState.update { state ->
            state.copy(workout = state.workout.copy(
                exercises = state.workout.exercises + we
            ))
        }
    }

    fun removeExercise(exerciseId: String) {
        _builderState.update { state ->
            state.copy(workout = state.workout.copy(
                exercises = state.workout.exercises.filterNot { it.exercise.id == exerciseId }
            ))
        }
    }

    fun updateSet(exerciseIndex: Int, setIndex: Int, updatedSet: SetEntry) {
        _builderState.update { state ->
            val exercises = state.workout.exercises.toMutableList()
            val we = exercises[exerciseIndex]
            val sets = we.sets.toMutableList()
            sets[setIndex] = updatedSet
            exercises[exerciseIndex] = we.copy(sets = sets)
            state.copy(workout = state.workout.copy(exercises = exercises))
        }
    }

    fun addSet(exerciseIndex: Int) {
        _builderState.update { state ->
            val exercises = state.workout.exercises.toMutableList()
            val we = exercises[exerciseIndex]
            val newSetNumber = we.sets.size + 1
            val lastSet = we.sets.lastOrNull()
            exercises[exerciseIndex] = we.copy(
                sets = we.sets + SetEntry(
                    setNumber  = newSetNumber,
                    targetReps = lastSet?.targetReps ?: 8,
                    weightKg   = lastSet?.weightKg ?: 0f,
                    restSeconds = lastSet?.restSeconds ?: 60
                )
            )
            state.copy(workout = state.workout.copy(exercises = exercises))
        }
    }

    fun saveWorkout() {
        val workout = _builderState.value.workout
        if (workout.name.isBlank()) {
            _builderState.update { it.copy(error = "Please enter a workout name") }
            return
        }
        viewModelScope.launch {
            _builderState.update { it.copy(isSaving = true) }
            when (val result = workoutRepository.saveWorkout(workout)) {
                is Result.Success -> _builderState.update { it.copy(isSaving = false, savedSuccessfully = true) }
                is Result.Error   -> _builderState.update { it.copy(isSaving = false, error = result.message) }
                else -> Unit
            }
        }
    }

    // ── Session Actions ────────────────────────────────────────────────────────

    /**
     * Start an active workout session from a template or scheduled workout.
     */
    fun startSession(workout: Workout) {
        _sessionState.update { WorkoutSessionUiState(workout = workout, isLoading = false) }
        startStopwatch()
    }

    fun completeSet() {
        val state = _sessionState.value
        val workout = state.workout ?: return
        val exercise = workout.exercises.getOrNull(state.currentExerciseIndex) ?: return
        val restSecs = exercise.sets.getOrNull(state.currentSetIndex)?.restSeconds ?: 60

        // Advance to next set or exercise
        val nextSet = state.currentSetIndex + 1
        val nextExercise = state.currentExerciseIndex + 1

        when {
            nextSet < exercise.sets.size -> {
                _sessionState.update { it.copy(currentSetIndex = nextSet) }
                startRestTimer(restSecs)
            }
            nextExercise < workout.exercises.size -> {
                _sessionState.update { it.copy(
                    currentExerciseIndex = nextExercise,
                    currentSetIndex      = 0
                )}
                startRestTimer(restSecs)
            }
            else -> completeWorkout()
        }
    }

    fun skipRest() {
        restTimerJob?.cancel()
        _sessionState.update { it.copy(isRestTimerActive = false, restTimeRemainingSeconds = 0) }
    }

    private fun startRestTimer(seconds: Int) {
        restTimerJob?.cancel()
        _sessionState.update { it.copy(isRestTimerActive = true, restTimeRemainingSeconds = seconds, totalRestSeconds = seconds) }
        restTimerJob = viewModelScope.launch {
            for (remaining in seconds downTo 0) {
                _sessionState.update { it.copy(restTimeRemainingSeconds = remaining) }
                if (remaining == 0) {
                    _sessionState.update { it.copy(isRestTimerActive = false) }
                    break
                }
                delay(1_000)
            }
        }
    }

    private fun startStopwatch() {
        stopwatchJob = viewModelScope.launch {
            while (true) {
                delay(1_000)
                _sessionState.update { it.copy(elapsedSeconds = it.elapsedSeconds + 1) }
            }
        }
    }

    private fun completeWorkout() {
        stopwatchJob?.cancel()
        restTimerJob?.cancel()
        val state = _sessionState.value
        val workout = state.workout ?: return
        viewModelScope.launch {
            val completed = workout.copy(
                status      = WorkoutStatus.COMPLETED,
                completedAt = LocalDateTime.now()
            )
            workoutRepository.saveWorkout(completed)
            _sessionState.update { it.copy(isWorkoutComplete = true) }
        }
    }

    private fun loadWorkoutForEdit(id: String) {
        viewModelScope.launch {
            val workout = workoutRepository.getWorkoutWithExercises(id)
            if (workout != null) {
                _builderState.update { it.copy(workout = workout) }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        restTimerJob?.cancel()
        stopwatchJob?.cancel()
    }
}
