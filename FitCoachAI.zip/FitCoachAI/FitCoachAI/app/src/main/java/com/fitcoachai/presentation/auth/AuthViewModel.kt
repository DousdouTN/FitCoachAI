package com.fitcoachai.presentation.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fitcoachai.core.data.repository.AuthRepository
import com.fitcoachai.core.utils.Result
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

// ─── UI State ─────────────────────────────────────────────────────────────────

data class AuthUiState(
    val isLoading: Boolean = false,
    val isLoggedIn: Boolean = false,
    val error: String? = null,
    val email: String = "",
    val password: String = "",
    val isPasswordVisible: Boolean = false,
    val isRegisterMode: Boolean = false
)

// ─── ViewModel ────────────────────────────────────────────────────────────────

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState(
        isLoggedIn = authRepository.isLoggedIn
    ))
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun onEmailChange(value: String)    = _uiState.update { it.copy(email = value, error = null) }
    fun onPasswordChange(value: String) = _uiState.update { it.copy(password = value, error = null) }
    fun togglePasswordVisibility()       = _uiState.update { it.copy(isPasswordVisible = !it.isPasswordVisible) }
    fun toggleMode()                     = _uiState.update { it.copy(isRegisterMode = !it.isRegisterMode, error = null) }

    /**
     * Handles both login and registration depending on [AuthUiState.isRegisterMode].
     * Validates input before hitting the network.
     */
    fun submit() {
        val state = _uiState.value
        if (!validate(state.email, state.password)) return

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }

            val result = if (state.isRegisterMode) {
                authRepository.registerWithEmail(state.email, state.password)
            } else {
                authRepository.signInWithEmail(state.email, state.password)
            }

            when (result) {
                is Result.Success -> _uiState.update { it.copy(isLoading = false, isLoggedIn = true) }
                is Result.Error   -> _uiState.update { it.copy(isLoading = false, error = result.message) }
                else -> Unit
            }
        }
    }

    /**
     * Google Sign-In — call after obtaining idToken from Google Sign-In SDK.
     */
    fun signInWithGoogle(idToken: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            when (val result = authRepository.signInWithGoogle(idToken)) {
                is Result.Success -> _uiState.update { it.copy(isLoading = false, isLoggedIn = true) }
                is Result.Error   -> _uiState.update { it.copy(isLoading = false, error = result.message) }
                else -> Unit
            }
        }
    }

    fun signOut() {
        authRepository.signOut()
        _uiState.update { AuthUiState(isLoggedIn = false) }
    }

    fun clearError() = _uiState.update { it.copy(error = null) }

    private fun validate(email: String, password: String): Boolean {
        return when {
            email.isBlank()    -> { _uiState.update { it.copy(error = "Email is required") }; false }
            !email.contains("@") -> { _uiState.update { it.copy(error = "Enter a valid email") }; false }
            password.length < 6 -> { _uiState.update { it.copy(error = "Password must be at least 6 characters") }; false }
            else -> true
        }
    }
}
