package com.fitcoachai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import com.fitcoachai.presentation.navigation.FitCoachNavHost
import com.fitcoachai.presentation.theme.FitCoachTheme
import com.google.firebase.auth.FirebaseAuth
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Single-activity architecture entry point.
 *
 * Responsibilities:
 * - Enables edge-to-edge rendering (immersive status bar)
 * - Checks current Firebase auth state to determine start destination
 * - Requests POST_NOTIFICATIONS permission on Android 13+
 * - Sets FitCoachTheme and mounts the root NavHost
 *
 * All navigation and UI logic is delegated to FitCoachNavHost.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var firebaseAuth: FirebaseAuth

    // ── Notification Permission (Android 13+) ─────────────────────────────────
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        // Silently proceed — notifications are non-critical for the core UX
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Extend content behind system bars for the premium dark look
        enableEdgeToEdge()

        // Request notification permission on Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        val isLoggedIn = firebaseAuth.currentUser != null

        setContent {
            FitCoachTheme(darkTheme = true) {
                FitCoachNavHost(isLoggedIn = isLoggedIn)
            }
        }
    }
}
