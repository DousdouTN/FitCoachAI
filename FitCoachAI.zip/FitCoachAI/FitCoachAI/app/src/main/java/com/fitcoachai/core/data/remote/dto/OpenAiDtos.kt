package com.fitcoachai.core.data.remote.dto

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

// ─── OpenAI Chat Completion DTOs ─────────────────────────────────────────────
// Matches the /v1/chat/completions endpoint schema.

@JsonClass(generateAdapter = true)
data class ChatRequest(
    val model: String = "gpt-4o-mini",        // Cost-efficient; swap for gpt-4o for higher quality
    val messages: List<MessageDto>,
    @Json(name = "max_tokens") val maxTokens: Int = 2048,
    val temperature: Float = 0.7f,
    val stream: Boolean = false               // Set true for streaming responses (SSE)
)

@JsonClass(generateAdapter = true)
data class MessageDto(
    val role: String,    // "system" | "user" | "assistant"
    val content: String
)

@JsonClass(generateAdapter = true)
data class ChatResponse(
    val id: String,
    val choices: List<ChoiceDto>,
    val usage: UsageDto?
)

@JsonClass(generateAdapter = true)
data class ChoiceDto(
    val message: MessageDto,
    @Json(name = "finish_reason") val finishReason: String
)

@JsonClass(generateAdapter = true)
data class UsageDto(
    @Json(name = "prompt_tokens")     val promptTokens: Int,
    @Json(name = "completion_tokens") val completionTokens: Int,
    @Json(name = "total_tokens")      val totalTokens: Int
)

// ─── Exercise API DTOs (e.g., ExerciseDB / Wger API) ─────────────────────────

@JsonClass(generateAdapter = true)
data class ExerciseApiDto(
    val id: String,
    val name: String,
    @Json(name = "target")         val targetMuscle: String,
    @Json(name = "secondaryMuscles") val secondaryMuscles: List<String> = emptyList(),
    val equipment: String,
    @Json(name = "gifUrl")         val animationUrl: String?,
    val instructions: List<String> = emptyList(),
    @Json(name = "bodyPart")       val bodyPart: String = ""
)
