package com.fitcoachai.core.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.fitcoachai.core.data.local.dao.*
import com.fitcoachai.core.data.local.entity.*

/**
 * Main Room database for FitCoachAI.
 *
 * All entities registered here. Version bump + migration strategies required
 * for any schema changes in production. During development, use
 * `fallbackToDestructiveMigration()` in the builder.
 */
@Database(
    entities = [
        UserProfileEntity::class,
        ExerciseEntity::class,
        WorkoutEntity::class,
        WorkoutExerciseEntity::class,
        BodyStatEntity::class,
        ChatMessageEntity::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class FitCoachDatabase : RoomDatabase() {
    abstract fun userProfileDao(): UserProfileDao
    abstract fun exerciseDao(): ExerciseDao
    abstract fun workoutDao(): WorkoutDao
    abstract fun workoutExerciseDao(): WorkoutExerciseDao
    abstract fun bodyStatDao(): BodyStatDao
    abstract fun chatMessageDao(): ChatMessageDao

    companion object {
        const val DB_NAME = "fitcoach_db"
    }
}
