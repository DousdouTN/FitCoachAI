package com.fitcoachai.presentation.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.fitcoachai.domain.model.Workout
import com.fitcoachai.domain.model.WorkoutStatus
import com.fitcoachai.presentation.components.*
import com.fitcoachai.presentation.theme.FitCoachColors

/**
 * Home / Dashboard screen.
 *
 * Layout:
 * ├── Greeting header + AI generate button
 * ├── Weekly summary stat row (KPI cards)
 * ├── Today's workouts
 * └── Streak banner
 */
@Composable
fun HomeScreen(
    onWorkoutClick: (workoutId: String) -> Unit,
    onStartWorkoutClick: (workoutId: String) -> Unit,
    onChatClick: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    LazyColumn(
        modifier            = Modifier
            .fillMaxSize()
            .background(FitCoachColors.Background),
        contentPadding      = PaddingValues(bottom = 100.dp)
    ) {

        // ── Header ────────────────────────────────────────────────────────
        item {
            HomeHeader(
                userName       = state.userProfile?.displayName ?: "Athlete",
                streakDays     = state.weeklySummary?.streakDays ?: 0,
                onChatClick    = onChatClick
            )
        }

        // ── Weekly Stats Row ──────────────────────────────────────────────
        item {
            val summary = state.weeklySummary
            LazyRow(
                modifier            = Modifier.fillMaxWidth(),
                contentPadding      = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    StatCard(
                        label      = "This Week",
                        value      = "${summary?.workoutsCompleted ?: 0}",
                        unit       = "/ ${summary?.workoutsPlanned ?: 0}",
                        icon       = Icons.Default.FitnessCenter,
                        accentColor = FitCoachColors.Primary,
                        modifier   = Modifier.width(140.dp)
                    )
                }
                item {
                    StatCard(
                        label      = "Volume",
                        value      = String.format("%.0f", summary?.totalVolumeKg ?: 0f),
                        unit       = "kg",
                        icon       = Icons.Default.BarChart,
                        accentColor = FitCoachColors.Secondary,
                        modifier   = Modifier.width(140.dp)
                    )
                }
                item {
                    StatCard(
                        label      = "Time",
                        value      = "${summary?.totalDurationMinutes ?: 0}",
                        unit       = "min",
                        icon       = Icons.Default.Timer,
                        accentColor = FitCoachColors.Warning,
                        modifier   = Modifier.width(140.dp)
                    )
                }
                item {
                    StatCard(
                        label      = "Streak",
                        value      = "${summary?.streakDays ?: 0}",
                        unit       = "days",
                        icon       = Icons.Default.LocalFire,
                        accentColor = FitCoachColors.HeartRed,
                        modifier   = Modifier.width(140.dp)
                    )
                }
            }
        }

        // ── AI Suggestion Banner ──────────────────────────────────────────
        item {
            Spacer(modifier = Modifier.height(24.dp))
            AiSuggestionBanner(
                onClick = {
                    viewModel.generateAiWorkoutSuggestion()
                    onChatClick()
                },
                modifier = Modifier.padding(horizontal = 20.dp)
            )
        }

        // ── Today's Workouts ──────────────────────────────────────────────
        item {
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text     = "Today's Plan",
                style    = MaterialTheme.typography.titleLarge,
                color    = FitCoachColors.TextPrimary,
                modifier = Modifier.padding(horizontal = 20.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
        }

        if (state.isLoading) {
            items(2) {
                ShimmerBox(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(90.dp)
                        .padding(horizontal = 20.dp, vertical = 6.dp)
                )
            }
        } else if (state.todayWorkouts.isEmpty()) {
            item {
                EmptyDayCard(
                    onGenerateClick = onChatClick,
                    modifier        = Modifier.padding(horizontal = 20.dp)
                )
            }
        } else {
            items(state.todayWorkouts) { workout ->
                TodayWorkoutCard(
                    workout        = workout,
                    onClick        = { onWorkoutClick(workout.id) },
                    onStartClick   = { onStartWorkoutClick(workout.id) },
                    modifier       = Modifier
                        .padding(horizontal = 20.dp, vertical = 6.dp)
                )
            }
        }
    }
}

// ─── Sub-composables ──────────────────────────────────────────────────────────

@Composable
private fun HomeHeader(
    userName: String,
    streakDays: Int,
    onChatClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 20.dp, top = 56.dp, bottom = 20.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment     = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text  = "Good morning,",
                style = MaterialTheme.typography.bodyMedium,
                color = FitCoachColors.TextSecondary
            )
            Text(
                text  = userName,
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = FitCoachColors.TextPrimary
            )
        }
        // AI Chat FAB shortcut
        IconButton(
            onClick = onChatClick,
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(FitCoachColors.Secondary.copy(alpha = 0.15f))
        ) {
            Icon(
                imageVector        = Icons.Default.AutoAwesome,
                contentDescription = "AI Coach",
                tint               = FitCoachColors.Secondary
            )
        }
    }
}

@Composable
private fun AiSuggestionBanner(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        colors   = CardDefaults.cardColors(containerColor = Color.Transparent),
        shape    = MaterialTheme.shapes.large
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        listOf(FitCoachColors.Secondary.copy(alpha = 0.3f), FitCoachColors.Primary.copy(alpha = 0.3f))
                    )
                )
                .padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Icon(
                    imageVector        = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint               = FitCoachColors.Primary,
                    modifier           = Modifier.size(32.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text  = "AI Workout Coach",
                        style = MaterialTheme.typography.titleSmall,
                        color = FitCoachColors.TextPrimary
                    )
                    Text(
                        text  = "Generate a personalized plan or ask anything",
                        style = MaterialTheme.typography.bodySmall,
                        color = FitCoachColors.TextSecondary
                    )
                }
                Icon(
                    imageVector        = Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint               = FitCoachColors.TextSecondary
                )
            }
        }
    }
}

@Composable
private fun TodayWorkoutCard(
    workout: Workout,
    onClick: () -> Unit,
    onStartClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick  = onClick,
        modifier = modifier.fillMaxWidth(),
        colors   = CardDefaults.cardColors(containerColor = FitCoachColors.Surface),
        shape    = MaterialTheme.shapes.medium
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment      = Alignment.CenterVertically,
                    horizontalArrangement  = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text  = workout.name,
                        style = MaterialTheme.typography.titleSmall,
                        color = FitCoachColors.TextPrimary
                    )
                    if (workout.createdByAI) {
                        Surface(
                            shape = MaterialTheme.shapes.extraSmall,
                            color = FitCoachColors.Secondary.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text     = "AI",
                                style    = MaterialTheme.typography.labelSmall,
                                color    = FitCoachColors.Secondary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text  = "${workout.exercises.size} exercises • ${workout.estimatedDurationMinutes} min",
                    style = MaterialTheme.typography.bodySmall,
                    color = FitCoachColors.TextSecondary
                )
            }

            when (workout.status) {
                WorkoutStatus.COMPLETED -> Icon(
                    imageVector        = Icons.Default.CheckCircle,
                    contentDescription = "Completed",
                    tint               = FitCoachColors.Primary
                )
                else -> FilledTonalButton(
                    onClick = onStartClick,
                    colors  = ButtonDefaults.filledTonalButtonColors(
                        containerColor = FitCoachColors.Primary.copy(alpha = 0.15f),
                        contentColor   = FitCoachColors.Primary
                    )
                ) {
                    Text("Start")
                }
            }
        }
    }
}

@Composable
private fun EmptyDayCard(
    onGenerateClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors   = CardDefaults.cardColors(containerColor = FitCoachColors.Surface),
        shape    = MaterialTheme.shapes.large
    ) {
        Column(
            modifier            = Modifier.padding(32.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector        = Icons.Default.SelfImprovement,
                contentDescription = null,
                tint               = FitCoachColors.TextMuted,
                modifier           = Modifier.size(48.dp)
            )
            Text(
                text  = "No workout planned",
                style = MaterialTheme.typography.titleSmall,
                color = FitCoachColors.TextSecondary
            )
            GradientButton(
                text    = "Generate with AI",
                onClick = onGenerateClick,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
