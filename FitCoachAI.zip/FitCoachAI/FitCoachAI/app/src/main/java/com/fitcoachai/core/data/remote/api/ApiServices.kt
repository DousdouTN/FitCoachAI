package com.fitcoachai.core.data.remote.api

import com.fitcoachai.core.data.remote.dto.ChatRequest
import com.fitcoachai.core.data.remote.dto.ChatResponse
import com.fitcoachai.core.data.remote.dto.ExerciseApiDto
import retrofit2.Response
import retrofit2.http.*

// ─── OpenAI API Service ───────────────────────────────────────────────────────

/**
 * Retrofit interface for OpenAI's Chat Completions endpoint.
 *
 * Base URL: https://api.openai.com/v1/
 * Authorization injected by [AuthInterceptor] in the OkHttp stack.
 */
interface OpenAiService {
    @POST("chat/completions")
    suspend fun createChatCompletion(
        @Body request: ChatRequest
    ): Response<ChatResponse>
}

// ─── Exercise Database API Service ────────────────────────────────────────────

/**
 * Retrofit interface for the public ExerciseDB API (rapidapi.com/justin-WFnsXH_t6/api/exercisedb).
 *
 * Base URL: https://exercisedb.p.rapidapi.com/
 * API key injected by [ExerciseApiInterceptor].
 *
 * Alternative free option: Wger REST API (wger.de/api/v2/) — no key required.
 */
interface ExerciseDbService {
    /** Fetch paginated exercise list (max 10 per request recommended). */
    @GET("exercises")
    suspend fun getExercises(
        @Query("limit")  limit: Int = 100,
        @Query("offset") offset: Int = 0
    ): Response<List<ExerciseApiDto>>

    /** Fetch exercises filtered by body part. */
    @GET("exercises/bodyPart/{bodyPart}")
    suspend fun getByBodyPart(
        @Path("bodyPart") bodyPart: String,
        @Query("limit")   limit: Int = 50,
        @Query("offset")  offset: Int = 0
    ): Response<List<ExerciseApiDto>>

    /** Fetch exercises filtered by target muscle. */
    @GET("exercises/target/{target}")
    suspend fun getByTarget(
        @Path("target") target: String,
        @Query("limit")  limit: Int = 50,
        @Query("offset") offset: Int = 0
    ): Response<List<ExerciseApiDto>>

    /** Fetch exercises filtered by equipment type. */
    @GET("exercises/equipment/{equipment}")
    suspend fun getByEquipment(
        @Path("equipment") equipment: String,
        @Query("limit")    limit: Int = 50,
        @Query("offset")   offset: Int = 0
    ): Response<List<ExerciseApiDto>>

    /** Search exercises by name. */
    @GET("exercises/name/{name}")
    suspend fun searchByName(
        @Path("name")   name: String,
        @Query("limit")  limit: Int = 20
    ): Response<List<ExerciseApiDto>>
}
