package com.fitcoachai.presentation.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import com.google.accompanist.systemuicontroller.rememberSystemUiController

// ─── Brand Palette ────────────────────────────────────────────────────────────
// Dark-first design. Primary accent: energetic cyan-teal.
// Surfaces are near-black for premium "sports app" feel.

object FitCoachColors {
    // Backgrounds
    val Background       = Color(0xFF0E0E0F)  // Almost black
    val Surface          = Color(0xFF1A1A1C)  // Card surface
    val SurfaceVariant   = Color(0xFF242427)  // Elevated card
    val SurfaceContainer = Color(0xFF2C2C30)  // Input / chip backgrounds

    // Accent — primary CTA, highlights
    val Primary          = Color(0xFF00E5C3)  // Vivid teal-green (Lyfta-style)
    val PrimaryDim       = Color(0xFF00B89B)  // Pressed / dimmed state
    val OnPrimary        = Color(0xFF002920)  // Text on primary buttons

    // Secondary accent
    val Secondary        = Color(0xFF7C6AF5)  // Purple — used for AI/chat
    val OnSecondary      = Color(0xFFFFFFFF)

    // Semantic
    val Error            = Color(0xFFFF5370)
    val Success          = Color(0xFF00E5C3)
    val Warning          = Color(0xFFFFAB40)

    // Text
    val TextPrimary      = Color(0xFFEEEEF0)
    val TextSecondary    = Color(0xFF9898A6)
    val TextMuted        = Color(0xFF5A5A66)

    // Misc
    val Divider          = Color(0xFF2A2A30)
    val HeartRed         = Color(0xFFFF3D6E)
}

private val DarkColorScheme = darkColorScheme(
    primary          = FitCoachColors.Primary,
    onPrimary        = FitCoachColors.OnPrimary,
    primaryContainer = FitCoachColors.PrimaryDim,
    secondary        = FitCoachColors.Secondary,
    onSecondary      = FitCoachColors.OnSecondary,
    background       = FitCoachColors.Background,
    surface          = FitCoachColors.Surface,
    surfaceVariant   = FitCoachColors.SurfaceVariant,
    onSurface        = FitCoachColors.TextPrimary,
    onSurfaceVariant = FitCoachColors.TextSecondary,
    error            = FitCoachColors.Error,
    outline          = FitCoachColors.Divider,
)

// Light scheme (minimal — app is dark-first)
private val LightColorScheme = lightColorScheme(
    primary          = Color(0xFF00957C),
    onPrimary        = Color(0xFFFFFFFF),
    background       = Color(0xFFF5F5F7),
    surface          = Color(0xFFFFFFFF),
    onSurface        = Color(0xFF1A1A1C),
)

/**
 * FitCoachAI application theme.
 *
 * @param darkTheme  Force dark mode (default true — app is dark-first).
 * @param content    Composable content slot.
 */
@Composable
fun FitCoachTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    // Transparent status bar so background bleeds through
    val systemUiController = rememberSystemUiController()
    SideEffect {
        systemUiController.setSystemBarsColor(
            color = Color.Transparent,
            darkIcons = !darkTheme
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography  = FitCoachTypography,
        shapes      = FitCoachShapes,
        content     = content
    )
}
