package com.fitcoachai.presentation.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fitcoachai.core.data.repository.AiChatRepository
import com.fitcoachai.core.utils.Result
import com.fitcoachai.domain.model.ChatMessage
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.util.UUID
import javax.inject.Inject

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val inputText: String = "",
    val isAiTyping: Boolean = false,
    val error: String? = null
)

// Predefined quick-access prompts shown as chips above the input
val QUICK_PROMPTS = listOf(
    "Create a 4-day push/pull split",
    "How to improve my bench press?",
    "Best exercises for lower back pain",
    "High-protein meal ideas for muscle gain",
    "How many rest days do I need?"
)

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val aiChatRepository: AiChatRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    init {
        // Observe persisted chat history from Room
        viewModelScope.launch {
            aiChatRepository.observeMessages().collect { messages ->
                _uiState.update { it.copy(messages = messages) }
            }
        }
    }

    fun onInputChange(text: String) = _uiState.update { it.copy(inputText = text) }

    /**
     * Send the current input message. Persists both the user message and
     * the AI response to Room for history continuity across sessions.
     */
    fun sendMessage() {
        val text = _uiState.value.inputText.trim()
        if (text.isBlank()) return

        val userMessage = ChatMessage(
            id         = UUID.randomUUID().toString(),
            content    = text,
            isFromUser = true,
            timestamp  = LocalDateTime.now()
        )

        viewModelScope.launch {
            // 1. Persist and display user message immediately
            aiChatRepository.saveMessage(userMessage)
            _uiState.update { it.copy(inputText = "", isAiTyping = true, error = null) }

            // 2. Send full conversation history for context-aware reply
            val history = _uiState.value.messages + userMessage
            when (val result = aiChatRepository.sendMessage(history)) {
                is Result.Success -> {
                    val aiMessage = ChatMessage(
                        id         = UUID.randomUUID().toString(),
                        content    = result.data,
                        isFromUser = false,
                        timestamp  = LocalDateTime.now()
                    )
                    aiChatRepository.saveMessage(aiMessage)
                    _uiState.update { it.copy(isAiTyping = false) }
                }
                is Result.Error -> {
                    _uiState.update { it.copy(isAiTyping = false, error = result.message) }
                }
                else -> Unit
            }
        }
    }

    fun sendQuickPrompt(prompt: String) {
        _uiState.update { it.copy(inputText = prompt) }
        sendMessage()
    }

    fun clearHistory() {
        viewModelScope.launch {
            aiChatRepository.clearHistory()
        }
    }

    fun clearError() = _uiState.update { it.copy(error = null) }
}
