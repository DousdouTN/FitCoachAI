package com.fitcoachai.core.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.fitcoachai.domain.model.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import java.time.LocalDate
import java.time.LocalDateTime

// ─── Room Type Converters ──────────────────────────────────────────────────────

/**
 * Room cannot serialize complex types natively — we use Moshi for JSON encoding.
 * This converters class handles all custom types used across entities.
 */
class Converters {
    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()

    @TypeConverter fun fromLocalDate(value: String?): LocalDate? = value?.let { LocalDate.parse(it) }
    @TypeConverter fun toLocalDate(date: LocalDate?): String? = date?.toString()

    @TypeConverter fun fromLocalDateTime(value: String?): LocalDateTime? = value?.let { LocalDateTime.parse(it) }
    @TypeConverter fun toLocalDateTime(dt: LocalDateTime?): String? = dt?.toString()

    @TypeConverter fun fromStringList(value: String): List<String> {
        val type = Types.newParameterizedType(List::class.java, String::class.java)
        return moshi.adapter<List<String>>(type).fromJson(value) ?: emptyList()
    }
    @TypeConverter fun toStringList(list: List<String>): String {
        val type = Types.newParameterizedType(List::class.java, String::class.java)
        return moshi.adapter<List<String>>(type).toJson(list)
    }

    @TypeConverter fun fromMuscleGroupList(value: String): List<MuscleGroup> =
        fromStringList(value).map { MuscleGroup.valueOf(it) }
    @TypeConverter fun toMuscleGroupList(list: List<MuscleGroup>): String =
        toStringList(list.map { it.name })

    @TypeConverter fun fromEquipmentList(value: String): List<Equipment> =
        fromStringList(value).map { Equipment.valueOf(it) }
    @TypeConverter fun toEquipmentList(list: List<Equipment>): String =
        toStringList(list.map { it.name })

    @TypeConverter fun fromSetEntryList(value: String): List<SetEntry> {
        val type = Types.newParameterizedType(List::class.java, SetEntry::class.java)
        return moshi.adapter<List<SetEntry>>(type).fromJson(value) ?: emptyList()
    }
    @TypeConverter fun toSetEntryList(list: List<SetEntry>): String {
        val type = Types.newParameterizedType(List::class.java, SetEntry::class.java)
        return moshi.adapter<List<SetEntry>>(type).toJson(list)
    }

    @TypeConverter fun fromFitnessGoal(value: String): FitnessGoal = FitnessGoal.valueOf(value)
    @TypeConverter fun toFitnessGoal(goal: FitnessGoal): String = goal.name

    @TypeConverter fun fromExperience(value: String): ExperienceLevel = ExperienceLevel.valueOf(value)
    @TypeConverter fun toExperience(level: ExperienceLevel): String = level.name

    @TypeConverter fun fromDifficulty(value: String): Difficulty = Difficulty.valueOf(value)
    @TypeConverter fun toDifficulty(d: Difficulty): String = d.name

    @TypeConverter fun fromEquipment(value: String): Equipment = Equipment.valueOf(value)
    @TypeConverter fun toEquipment(e: Equipment): String = e.name

    @TypeConverter fun fromWorkoutStatus(value: String): WorkoutStatus = WorkoutStatus.valueOf(value)
    @TypeConverter fun toWorkoutStatus(s: WorkoutStatus): String = s.name
}

// ─── Room Entities ─────────────────────────────────────────────────────────────

@Entity(tableName = "user_profiles")
@TypeConverters(Converters::class)
data class UserProfileEntity(
    @PrimaryKey val uid: String,
    val email: String,
    val displayName: String,
    val photoUrl: String?,
    val age: Int,
    val weightKg: Float,
    val heightCm: Float,
    val goal: FitnessGoal,
    val experience: ExperienceLevel,
    val availableEquipment: List<Equipment>,
    val workoutsPerWeek: Int,
    val createdAt: LocalDateTime
)

@Entity(tableName = "exercises")
@TypeConverters(Converters::class)
data class ExerciseEntity(
    @PrimaryKey val id: String,
    val name: String,
    val targetMuscles: List<MuscleGroup>,
    val secondaryMuscles: List<MuscleGroup>,
    val equipment: Equipment,
    val difficulty: Difficulty,
    val instructions: List<String>,
    val tips: List<String>,
    val animationUrl: String?,
    val thumbnailUrl: String?,
    val videoUrl: String?,
    val isFavorite: Boolean,
    val category: String
)

@Entity(tableName = "workouts")
@TypeConverters(Converters::class)
data class WorkoutEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val estimatedDurationMinutes: Int,
    val status: WorkoutStatus,
    val scheduledDate: LocalDate?,
    val completedAt: LocalDateTime?,
    val totalVolumeKg: Float,
    val notes: String,
    val isTemplate: Boolean,
    val createdByAI: Boolean,
    val programId: String?
)

/**
 * Join entity: links a workout to its exercises with set data.
 * One WorkoutEntity → many WorkoutExerciseEntity rows.
 */
@Entity(
    tableName = "workout_exercises",
    foreignKeys = [
        ForeignKey(
            entity       = WorkoutEntity::class,
            parentColumns = ["id"],
            childColumns  = ["workoutId"],
            onDelete      = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity       = ExerciseEntity::class,
            parentColumns = ["id"],
            childColumns  = ["exerciseId"],
            onDelete      = ForeignKey.CASCADE
        )
    ],
    indices = [Index("workoutId"), Index("exerciseId")]
)
@TypeConverters(Converters::class)
data class WorkoutExerciseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workoutId: String,
    val exerciseId: String,
    val sets: List<SetEntry>,
    val notes: String,
    val orderIndex: Int
)

@Entity(tableName = "body_stats")
@TypeConverters(Converters::class)
data class BodyStatEntity(
    @PrimaryKey val id: String,
    val weightKg: Float,
    val bodyFatPercent: Float?,
    val muscleMassKg: Float?,
    val date: LocalDate,
    val notes: String
)

@Entity(tableName = "chat_messages")
@TypeConverters(Converters::class)
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val content: String,
    val isFromUser: Boolean,
    val timestamp: LocalDateTime
)
