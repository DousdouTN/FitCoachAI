package com.fitcoachai.presentation.progress

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fitcoachai.core.data.repository.BodyStatRepository
import com.fitcoachai.core.data.repository.WorkoutRepository
import com.fitcoachai.core.utils.Result
import com.fitcoachai.domain.model.BodyStat
import com.fitcoachai.domain.model.Workout
import com.fitcoachai.domain.model.WorkoutStatus
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.UUID
import javax.inject.Inject

enum class ProgressPeriod(val label: String, val days: Long) {
    WEEK_1("1W", 7),
    WEEK_4("1M", 30),
    WEEK_12("3M", 90),
    ALL("All", Long.MAX_VALUE)
}

data class ProgressUiState(
    val bodyStats: List<BodyStat> = emptyList(),
    val completedWorkouts: List<Workout> = emptyList(),
    val selectedPeriod: ProgressPeriod = ProgressPeriod.WEEK_4,
    val newWeightInput: String = "",
    val newBodyFatInput: String = "",
    val isSavingBodyStat: Boolean = false,
    val isLoading: Boolean = true,
    val error: String? = null,
    val showAddStatDialog: Boolean = false
)

@HiltViewModel
class ProgressViewModel @Inject constructor(
    private val bodyStatRepository: BodyStatRepository,
    private val workoutRepository: WorkoutRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProgressUiState())
    val uiState: StateFlow<ProgressUiState> = _uiState.asStateFlow()

    /** Filtered stats based on selected period — derived from uiState. */
    val filteredStats: StateFlow<List<BodyStat>> = uiState.map { state ->
        val since = when (state.selectedPeriod) {
            ProgressPeriod.ALL -> LocalDate.ofEpochDay(0)
            else -> LocalDate.now().minusDays(state.selectedPeriod.days)
        }
        state.bodyStats.filter { !it.date.isBefore(since) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        viewModelScope.launch {
            combine(
                bodyStatRepository.observeAllStats(),
                workoutRepository.observeCompletedWorkouts()
            ) { stats, workouts ->
                _uiState.update { it.copy(
                    bodyStats          = stats,
                    completedWorkouts  = workouts,
                    isLoading          = false
                )}
            }.collect()
        }
    }

    fun selectPeriod(period: ProgressPeriod) = _uiState.update { it.copy(selectedPeriod = period) }
    fun onWeightInput(value: String)          = _uiState.update { it.copy(newWeightInput = value) }
    fun onBodyFatInput(value: String)         = _uiState.update { it.copy(newBodyFatInput = value) }
    fun showAddStatDialog()                   = _uiState.update { it.copy(showAddStatDialog = true) }
    fun hideAddStatDialog()                   = _uiState.update { it.copy(showAddStatDialog = false) }

    fun saveBodyStat() {
        val weight = _uiState.value.newWeightInput.toFloatOrNull()
        if (weight == null || weight <= 0) {
            _uiState.update { it.copy(error = "Please enter a valid weight") }
            return
        }
        val bodyFat = _uiState.value.newBodyFatInput.toFloatOrNull()

        viewModelScope.launch {
            _uiState.update { it.copy(isSavingBodyStat = true) }
            val stat = BodyStat(
                id             = UUID.randomUUID().toString(),
                weightKg       = weight,
                bodyFatPercent = bodyFat,
                date           = LocalDate.now()
            )
            when (val result = bodyStatRepository.saveStat(stat)) {
                is Result.Success -> _uiState.update { it.copy(
                    isSavingBodyStat = false,
                    showAddStatDialog = false,
                    newWeightInput    = "",
                    newBodyFatInput   = ""
                )}
                is Result.Error -> _uiState.update { it.copy(isSavingBodyStat = false, error = result.message) }
                else -> Unit
            }
        }
    }
}
