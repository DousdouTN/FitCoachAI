package com.fitcoachai.domain.model

import java.time.LocalDate
import java.time.LocalDateTime

// ─── Enumerations ─────────────────────────────────────────────────────────────

enum class FitnessGoal(val displayName: String) {
    MUSCLE_GAIN("Muscle Gain"),
    FAT_LOSS("Fat Loss"),
    STRENGTH("Strength"),
    ENDURANCE("Endurance"),
    GENERAL_FITNESS("General Fitness")
}

enum class ExperienceLevel(val displayName: String) {
    BEGINNER("Beginner"),
    INTERMEDIATE("Intermediate"),
    ADVANCED("Advanced")
}

enum class MuscleGroup(val displayName: String) {
    CHEST("Chest"),
    BACK("Back"),
    SHOULDERS("Shoulders"),
    BICEPS("Biceps"),
    TRICEPS("Triceps"),
    FOREARMS("Forearms"),
    CORE("Core / Abs"),
    QUADS("Quadriceps"),
    HAMSTRINGS("Hamstrings"),
    GLUTES("Glutes"),
    CALVES("Calves"),
    FULL_BODY("Full Body"),
    CARDIO("Cardio")
}

enum class Equipment(val displayName: String) {
    BARBELL("Barbell"),
    DUMBBELL("Dumbbell"),
    KETTLEBELL("Kettlebell"),
    CABLE("Cable Machine"),
    MACHINE("Machine"),
    BODYWEIGHT("Bodyweight"),
    RESISTANCE_BAND("Resistance Band"),
    PULL_UP_BAR("Pull-up Bar"),
    BENCH("Bench"),
    NONE("No Equipment")
}

enum class Difficulty(val displayName: String) {
    BEGINNER("Beginner"),
    INTERMEDIATE("Intermediate"),
    ADVANCED("Advanced")
}

enum class WorkoutStatus { PLANNED, IN_PROGRESS, COMPLETED, SKIPPED }

// ─── Core Domain Models ────────────────────────────────────────────────────────

/**
 * Authenticated user profile stored both in Firebase and local Room cache.
 */
data class UserProfile(
    val uid: String,
    val email: String,
    val displayName: String,
    val photoUrl: String? = null,
    val age: Int = 0,
    val weightKg: Float = 0f,
    val heightCm: Float = 0f,
    val goal: FitnessGoal = FitnessGoal.GENERAL_FITNESS,
    val experience: ExperienceLevel = ExperienceLevel.BEGINNER,
    val availableEquipment: List<Equipment> = emptyList(),
    val workoutsPerWeek: Int = 3,
    val createdAt: LocalDateTime = LocalDateTime.now()
)

/**
 * An individual exercise from the library.
 * [animationUrl] can point to a GIF or Lottie JSON for in-app animation.
 */
data class Exercise(
    val id: String,
    val name: String,
    val targetMuscles: List<MuscleGroup>,
    val secondaryMuscles: List<MuscleGroup> = emptyList(),
    val equipment: Equipment,
    val difficulty: Difficulty,
    val instructions: List<String>,        // Step-by-step numbered instructions
    val tips: List<String> = emptyList(),  // Coaching cues
    val animationUrl: String? = null,      // GIF / Lottie URL
    val thumbnailUrl: String? = null,
    val videoUrl: String? = null,
    val isFavorite: Boolean = false,
    val category: String = ""
)

/**
 * One set entry for an exercise within a workout log.
 */
data class SetEntry(
    val setNumber: Int,
    val targetReps: Int,
    val completedReps: Int? = null,
    val weightKg: Float = 0f,
    val restSeconds: Int = 60,
    val isCompleted: Boolean = false,
    val rpe: Int? = null  // Rate of Perceived Exertion 1-10
)

/**
 * A single exercise block inside a workout plan.
 */
data class WorkoutExercise(
    val exercise: Exercise,
    val sets: List<SetEntry>,
    val notes: String = "",
    val orderIndex: Int = 0
)

/**
 * A complete workout session — can be a template or a logged instance.
 */
data class Workout(
    val id: String,
    val name: String,
    val description: String = "",
    val exercises: List<WorkoutExercise>,
    val estimatedDurationMinutes: Int = 45,
    val status: WorkoutStatus = WorkoutStatus.PLANNED,
    val scheduledDate: LocalDate? = null,
    val completedAt: LocalDateTime? = null,
    val totalVolumeKg: Float = 0f,   // Sum of (weight × reps) across all sets
    val notes: String = "",
    val isTemplate: Boolean = false,
    val createdByAI: Boolean = false,
    val programId: String? = null
)

/**
 * A multi-week structured training program.
 */
data class TrainingProgram(
    val id: String,
    val name: String,
    val description: String,
    val durationWeeks: Int,
    val daysPerWeek: Int,
    val goal: FitnessGoal,
    val difficulty: Difficulty,
    val workoutTemplates: List<Workout>,  // Template workouts forming the program
    val createdByAI: Boolean = false
)

/**
 * A single body-weight measurement data point.
 */
data class BodyStat(
    val id: String,
    val weightKg: Float,
    val bodyFatPercent: Float? = null,
    val muscleMassKg: Float? = null,
    val date: LocalDate,
    val notes: String = ""
)

/**
 * Personal Record for a specific exercise.
 */
data class PersonalRecord(
    val exerciseId: String,
    val exerciseName: String,
    val maxWeightKg: Float,
    val maxReps: Int,
    val achievedOn: LocalDate
)

/**
 * Chat message entity for the AI assistant interface.
 */
data class ChatMessage(
    val id: String,
    val content: String,
    val isFromUser: Boolean,
    val timestamp: LocalDateTime = LocalDateTime.now(),
    val isLoading: Boolean = false   // Skeleton state while AI responds
)

/**
 * Aggregated weekly progress summary for the home dashboard.
 */
data class WeeklySummary(
    val weekStartDate: LocalDate,
    val workoutsCompleted: Int,
    val workoutsPlanned: Int,
    val totalVolumeKg: Float,
    val totalDurationMinutes: Int,
    val streakDays: Int
)
