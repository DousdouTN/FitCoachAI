package com.fitcoachai.presentation.workout

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.fitcoachai.domain.model.*
import com.fitcoachai.presentation.components.GradientButton
import com.fitcoachai.presentation.components.RestTimerRing
import com.fitcoachai.presentation.theme.FitCoachColors

// ─── Workout Builder Screen ───────────────────────────────────────────────────

/**
 * Create / edit a workout by adding exercises and configuring sets.
 *
 * @param onAddExercise  Navigate to Exercise Library with a selection callback.
 * @param onSaved        Called after successful save.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkoutBuilderScreen(
    onAddExercise: () -> Unit,
    onSaved: () -> Unit,
    viewModel: WorkoutViewModel = hiltViewModel()
) {
    val state by viewModel.builderState.collectAsState()

    // Navigate on successful save
    LaunchedEffect(state.savedSuccessfully) {
        if (state.savedSuccessfully) onSaved()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(FitCoachColors.Background)
    ) {
        // ── Top Bar ────────────────────────────────────────────────────────
        TopAppBar(
            title = {
                OutlinedTextField(
                    value         = state.workout.name,
                    onValueChange = viewModel::onWorkoutNameChange,
                    placeholder   = { Text("Workout name...", color = FitCoachColors.TextMuted) },
                    singleLine    = true,
                    colors        = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor   = FitCoachColors.Primary,
                        unfocusedBorderColor = FitCoachColors.Divider,
                        focusedTextColor     = FitCoachColors.TextPrimary,
                        unfocusedTextColor   = FitCoachColors.TextPrimary
                    ),
                    textStyle = MaterialTheme.typography.titleMedium
                )
            },
            actions = {
                IconButton(onClick = viewModel::saveWorkout) {
                    if (state.isSaving) CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color    = FitCoachColors.Primary,
                        strokeWidth = 2.dp
                    ) else Icon(
                        Icons.Default.Save,
                        contentDescription = "Save",
                        tint = FitCoachColors.Primary
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = FitCoachColors.Background,
                titleContentColor = FitCoachColors.TextPrimary
            )
        )

        LazyColumn(
            modifier            = Modifier.weight(1f),
            contentPadding      = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // ── Exercise list ──────────────────────────────────────────────
            itemsIndexed(state.workout.exercises) { exerciseIndex, we ->
                WorkoutExerciseCard(
                    workoutExercise = we,
                    exerciseIndex   = exerciseIndex,
                    onSetChanged    = { setIndex, set -> viewModel.updateSet(exerciseIndex, setIndex, set) },
                    onAddSet        = { viewModel.addSet(exerciseIndex) },
                    onRemove        = { viewModel.removeExercise(we.exercise.id) }
                )
            }

            // ── Add Exercise button ────────────────────────────────────────
            item {
                OutlinedButton(
                    onClick   = onAddExercise,
                    modifier  = Modifier.fillMaxWidth().height(52.dp),
                    colors    = ButtonDefaults.outlinedButtonColors(contentColor = FitCoachColors.Primary),
                    border    = androidx.compose.foundation.BorderStroke(1.dp, FitCoachColors.Primary.copy(alpha = 0.5f))
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Add Exercise")
                }
            }
        }

        // ── Error snackbar ─────────────────────────────────────────────────
        state.error?.let { error ->
            Snackbar(
                modifier        = Modifier.padding(16.dp),
                containerColor  = FitCoachColors.Error,
                action          = {
                    TextButton(onClick = { /* clear error */ }) {
                        Text("Dismiss", color = FitCoachColors.TextPrimary)
                    }
                }
            ) { Text(error) }
        }
    }
}

// ─── Exercise Entry Card in Builder ──────────────────────────────────────────

@Composable
private fun WorkoutExerciseCard(
    workoutExercise: WorkoutExercise,
    exerciseIndex: Int,
    onSetChanged: (Int, SetEntry) -> Unit,
    onAddSet: () -> Unit,
    onRemove: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = FitCoachColors.Surface),
        shape  = MaterialTheme.shapes.medium
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Exercise header
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text     = workoutExercise.exercise.name,
                    style    = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                    color    = FitCoachColors.TextPrimary,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onRemove) {
                    Icon(Icons.Default.Delete, contentDescription = "Remove", tint = FitCoachColors.Error)
                }
            }
            Text(
                text  = workoutExercise.exercise.targetMuscles.joinToString { it.displayName },
                style = MaterialTheme.typography.bodySmall,
                color = FitCoachColors.TextSecondary
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Sets header
            Row(modifier = Modifier.fillMaxWidth()) {
                Text("Set", style = MaterialTheme.typography.labelSmall, color = FitCoachColors.TextMuted, modifier = Modifier.width(36.dp))
                Text("Reps", style = MaterialTheme.typography.labelSmall, color = FitCoachColors.TextMuted, modifier = Modifier.weight(1f))
                Text("Weight (kg)", style = MaterialTheme.typography.labelSmall, color = FitCoachColors.TextMuted, modifier = Modifier.weight(1f))
                Text("Rest (s)", style = MaterialTheme.typography.labelSmall, color = FitCoachColors.TextMuted, modifier = Modifier.weight(1f))
            }

            HorizontalDivider(color = FitCoachColors.Divider, modifier = Modifier.padding(vertical = 4.dp))

            // Set rows
            workoutExercise.sets.forEachIndexed { setIndex, setEntry ->
                SetRow(
                    setEntry   = setEntry,
                    onChanged  = { updated -> onSetChanged(setIndex, updated) }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            TextButton(
                onClick = onAddSet,
                colors  = ButtonDefaults.textButtonColors(contentColor = FitCoachColors.Primary)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Set", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
private fun SetRow(
    setEntry: SetEntry,
    onChanged: (SetEntry) -> Unit
) {
    Row(
        modifier          = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text  = "${setEntry.setNumber}",
            style = MaterialTheme.typography.bodySmall,
            color = FitCoachColors.Primary,
            modifier = Modifier.width(36.dp)
        )
        // Reps input
        NumberInputField(
            value     = setEntry.targetReps.toString(),
            onChanged = { onChanged(setEntry.copy(targetReps = it.toIntOrNull() ?: setEntry.targetReps)) },
            modifier  = Modifier.weight(1f).padding(end = 8.dp)
        )
        // Weight input
        NumberInputField(
            value     = if (setEntry.weightKg == 0f) "" else setEntry.weightKg.toString(),
            onChanged = { onChanged(setEntry.copy(weightKg = it.toFloatOrNull() ?: 0f)) },
            modifier  = Modifier.weight(1f).padding(end = 8.dp)
        )
        // Rest input
        NumberInputField(
            value     = setEntry.restSeconds.toString(),
            onChanged = { onChanged(setEntry.copy(restSeconds = it.toIntOrNull() ?: 60)) },
            modifier  = Modifier.weight(1f)
        )
    }
}

@Composable
private fun NumberInputField(
    value: String,
    onChanged: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value         = value,
        onValueChange = onChanged,
        singleLine    = true,
        textStyle     = MaterialTheme.typography.bodySmall,
        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
            keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal
        ),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor   = FitCoachColors.Primary,
            unfocusedBorderColor = FitCoachColors.Divider,
            focusedTextColor     = FitCoachColors.TextPrimary,
            unfocusedTextColor   = FitCoachColors.TextPrimary
        ),
        modifier = modifier.height(44.dp)
    )
}

// ─── Active Workout Session Screen ────────────────────────────────────────────

/**
 * Full-screen active session view.
 * Shows current exercise, set progress, rest timer, and elapsed time.
 */
@Composable
fun WorkoutSessionScreen(
    workoutId: String,
    onComplete: () -> Unit,
    viewModel: WorkoutViewModel = hiltViewModel()
) {
    val state by viewModel.sessionState.collectAsState()

    LaunchedEffect(workoutId) {
        val workout = viewModel.listUiState.value.templates
            .firstOrNull { it.id == workoutId }
        workout?.let { viewModel.startSession(it) }
    }

    LaunchedEffect(state.isWorkoutComplete) {
        if (state.isWorkoutComplete) onComplete()
    }

    val workout = state.workout ?: return
    val currentExercise = workout.exercises.getOrNull(state.currentExerciseIndex)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(FitCoachColors.Background)
    ) {
        Column(
            modifier            = Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(40.dp))

            // ── Elapsed time ───────────────────────────────────────────────
            Text(
                text  = String.format("%02d:%02d", state.elapsedSeconds / 60, state.elapsedSeconds % 60),
                style = MaterialTheme.typography.displaySmall,
                color = FitCoachColors.TextPrimary
            )
            Text("Elapsed", style = MaterialTheme.typography.labelSmall, color = FitCoachColors.TextSecondary)

            Spacer(modifier = Modifier.height(32.dp))

            if (state.isRestTimerActive) {
                // ── Rest Timer ─────────────────────────────────────────────
                RestTimerRing(
                    remainingSeconds = state.restTimeRemainingSeconds,
                    totalSeconds     = state.totalRestSeconds,
                    modifier         = Modifier.size(180.dp)
                )
                Spacer(modifier = Modifier.height(24.dp))
                OutlinedButton(
                    onClick = viewModel::skipRest,
                    colors  = ButtonDefaults.outlinedButtonColors(contentColor = FitCoachColors.Primary)
                ) {
                    Text("Skip Rest")
                }
            } else if (currentExercise != null) {
                // ── Current Exercise ───────────────────────────────────────
                Text(
                    text  = currentExercise.exercise.name,
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                    color = FitCoachColors.TextPrimary
                )
                Text(
                    text  = currentExercise.exercise.targetMuscles.joinToString { it.displayName },
                    style = MaterialTheme.typography.bodyMedium,
                    color = FitCoachColors.TextSecondary
                )

                Spacer(modifier = Modifier.height(16.dp))

                val currentSet = currentExercise.sets.getOrNull(state.currentSetIndex)
                if (currentSet != null) {
                    Text(
                        text  = "Set ${state.currentSetIndex + 1} / ${currentExercise.sets.size}",
                        style = MaterialTheme.typography.titleLarge,
                        color = FitCoachColors.Primary
                    )
                    Text(
                        text  = "${currentSet.targetReps} reps @ ${currentSet.weightKg} kg",
                        style = MaterialTheme.typography.bodyLarge,
                        color = FitCoachColors.TextSecondary
                    )
                }

                Spacer(modifier = Modifier.height(32.dp))

                // Exercise progress indicator
                Text(
                    text  = "Exercise ${state.currentExerciseIndex + 1} of ${workout.exercises.size}",
                    style = MaterialTheme.typography.bodySmall,
                    color = FitCoachColors.TextMuted
                )
                LinearProgressIndicator(
                    progress    = { (state.currentExerciseIndex + 1f) / workout.exercises.size },
                    modifier    = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    color       = FitCoachColors.Primary,
                    trackColor  = FitCoachColors.SurfaceVariant
                )

                Spacer(modifier = Modifier.weight(1f))

                GradientButton(
                    text     = "Complete Set",
                    onClick  = viewModel::completeSet,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
