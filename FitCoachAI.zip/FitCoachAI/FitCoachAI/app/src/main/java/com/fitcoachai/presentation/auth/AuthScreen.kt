package com.fitcoachai.presentation.auth

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.fitcoachai.presentation.components.GradientButton
import com.fitcoachai.presentation.theme.FitCoachColors

/**
 * Authentication screen — handles both login and registration.
 *
 * Design: Full-screen dark background, brand gradient header,
 * centered card with email/password form. Google Sign-In below.
 *
 * @param onAuthenticated  Called after successful auth to trigger navigation.
 */
@Composable
fun AuthScreen(
    onAuthenticated: () -> Unit,
    viewModel: AuthViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    val focusManager = LocalFocusManager.current

    // Navigate on successful login
    LaunchedEffect(state.isLoggedIn) {
        if (state.isLoggedIn) onAuthenticated()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(FitCoachColors.Background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Spacer(modifier = Modifier.height(72.dp))

            // ── Brand Hero ─────────────────────────────────────────────────
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(
                        Brush.radialGradient(listOf(FitCoachColors.Primary.copy(alpha = 0.3f), FitCoachColors.Background)),
                        shape = androidx.compose.foundation.shape.CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector        = Icons.Default.FitnessCenter,
                    contentDescription = "Logo",
                    tint               = FitCoachColors.Primary,
                    modifier           = Modifier.size(40.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text  = "FitCoach AI",
                style = MaterialTheme.typography.headlineLarge,
                color = FitCoachColors.TextPrimary
            )
            Text(
                text  = "Your intelligent fitness partner",
                style = MaterialTheme.typography.bodyMedium,
                color = FitCoachColors.TextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(40.dp))

            // ── Mode Toggle ────────────────────────────────────────────────
            AnimatedContent(
                targetState = state.isRegisterMode,
                label       = "auth_mode"
            ) { isRegister ->
                Text(
                    text  = if (isRegister) "Create Account" else "Welcome Back",
                    style = MaterialTheme.typography.titleLarge,
                    color = FitCoachColors.TextPrimary
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // ── Email Field ────────────────────────────────────────────────
            OutlinedTextField(
                value         = state.email,
                onValueChange = viewModel::onEmailChange,
                label         = { Text("Email") },
                leadingIcon   = { Icon(Icons.Default.Email, contentDescription = null) },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email,
                    imeAction    = ImeAction.Next
                ),
                singleLine  = true,
                isError     = state.error != null,
                modifier    = Modifier.fillMaxWidth(),
                colors      = authTextFieldColors()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // ── Password Field ─────────────────────────────────────────────
            OutlinedTextField(
                value         = state.password,
                onValueChange = viewModel::onPasswordChange,
                label         = { Text("Password") },
                leadingIcon   = { Icon(Icons.Default.Lock, contentDescription = null) },
                trailingIcon  = {
                    IconButton(onClick = viewModel::togglePasswordVisibility) {
                        Icon(
                            imageVector        = if (state.isPasswordVisible) Icons.Default.VisibilityOff
                                                 else Icons.Default.Visibility,
                            contentDescription = "Toggle password"
                        )
                    }
                },
                visualTransformation = if (state.isPasswordVisible) VisualTransformation.None
                                       else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction    = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = {
                    focusManager.clearFocus()
                    viewModel.submit()
                }),
                singleLine  = true,
                isError     = state.error != null,
                modifier    = Modifier.fillMaxWidth(),
                colors      = authTextFieldColors()
            )

            // ── Error Message ──────────────────────────────────────────────
            AnimatedVisibility(visible = state.error != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text  = state.error ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = FitCoachColors.Error
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // ── Submit Button ──────────────────────────────────────────────
            GradientButton(
                text    = if (state.isRegisterMode) "Create Account" else "Sign In",
                onClick = viewModel::submit,
                enabled = !state.isLoading,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // ── Mode Switch ────────────────────────────────────────────────
            TextButton(onClick = viewModel::toggleMode) {
                Text(
                    text  = if (state.isRegisterMode) "Already have an account? Sign in"
                             else "Don't have an account? Register",
                    color = FitCoachColors.Primary
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ── Divider ────────────────────────────────────────────────────
            Row(
                modifier    = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                HorizontalDivider(modifier = Modifier.weight(1f), color = FitCoachColors.Divider)
                Text(
                    text     = "  or  ",
                    style    = MaterialTheme.typography.bodySmall,
                    color    = FitCoachColors.TextSecondary
                )
                HorizontalDivider(modifier = Modifier.weight(1f), color = FitCoachColors.Divider)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ── Google Sign-In ─────────────────────────────────────────────
            // In production, integrate with Google Identity Services SDK.
            // The idToken from the Google sign-in result is passed to the ViewModel.
            OutlinedButton(
                onClick   = { /* Launch Google Sign-In intent — see MainActivity */ },
                modifier  = Modifier.fillMaxWidth().height(52.dp),
                colors    = ButtonDefaults.outlinedButtonColors(contentColor = FitCoachColors.TextPrimary),
                border    = androidx.compose.foundation.BorderStroke(1.dp, FitCoachColors.Divider)
            ) {
                Icon(
                    imageVector        = Icons.Default.AccountCircle,
                    contentDescription = "Google",
                    tint               = FitCoachColors.Primary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Continue with Google")
            }

            // Loading overlay
            if (state.isLoading) {
                Spacer(modifier = Modifier.height(16.dp))
                CircularProgressIndicator(color = FitCoachColors.Primary)
            }
        }
    }
}

@Composable
private fun authTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor   = FitCoachColors.Primary,
    unfocusedBorderColor = FitCoachColors.Divider,
    focusedLabelColor    = FitCoachColors.Primary,
    unfocusedLabelColor  = FitCoachColors.TextSecondary,
    cursorColor          = FitCoachColors.Primary,
    focusedTextColor     = FitCoachColors.TextPrimary,
    unfocusedTextColor   = FitCoachColors.TextPrimary
)
