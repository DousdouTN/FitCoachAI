package com.fitcoachai.presentation.exercise

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fitcoachai.core.data.repository.ExerciseRepository
import com.fitcoachai.domain.model.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ExerciseListUiState(
    val exercises: List<Exercise> = emptyList(),
    val isLoading: Boolean = true,
    val searchQuery: String = "",
    val selectedMuscleGroup: MuscleGroup? = null,
    val selectedEquipment: Equipment? = null,
    val selectedDifficulty: Difficulty? = null,
    val showFavoritesOnly: Boolean = false,
    val error: String? = null
)

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
@HiltViewModel
class ExerciseViewModel @Inject constructor(
    private val exerciseRepository: ExerciseRepository
) : ViewModel() {

    private val _filters = MutableStateFlow(ExerciseListUiState())
    val uiState: StateFlow<ExerciseListUiState> = _filters
        .debounce(300)  // Debounce search input to avoid excessive DB queries
        .flatMapLatest { state ->
            val flow = if (state.showFavoritesOnly) {
                exerciseRepository.observeFavorites()
            } else if (state.searchQuery.isNotBlank()) {
                exerciseRepository.searchExercises(state.searchQuery)
            } else {
                exerciseRepository.observeExercises()
            }
            flow.map { exercises ->
                // Apply in-memory filters (muscle group, equipment, difficulty)
                val filtered = exercises.filter { exercise ->
                    (state.selectedMuscleGroup == null || state.selectedMuscleGroup in exercise.targetMuscles) &&
                    (state.selectedEquipment == null || state.selectedEquipment == exercise.equipment) &&
                    (state.selectedDifficulty == null || state.selectedDifficulty == exercise.difficulty)
                }
                state.copy(exercises = filtered, isLoading = false)
            }
        }
        .catch { e -> emit(_filters.value.copy(isLoading = false, error = e.message)) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ExerciseListUiState())

    fun onSearchQueryChange(query: String)         = _filters.update { it.copy(searchQuery = query, isLoading = true) }
    fun onMuscleGroupFilter(mg: MuscleGroup?)      = _filters.update { it.copy(selectedMuscleGroup = mg) }
    fun onEquipmentFilter(eq: Equipment?)          = _filters.update { it.copy(selectedEquipment = eq) }
    fun onDifficultyFilter(diff: Difficulty?)      = _filters.update { it.copy(selectedDifficulty = diff) }
    fun toggleFavoritesOnly()                       = _filters.update { it.copy(showFavoritesOnly = !it.showFavoritesOnly) }
    fun clearFilters()                              = _filters.update { it.copy(
        searchQuery           = "",
        selectedMuscleGroup   = null,
        selectedEquipment     = null,
        selectedDifficulty    = null,
        showFavoritesOnly     = false
    )}

    fun toggleFavorite(exercise: Exercise) {
        viewModelScope.launch {
            exerciseRepository.toggleFavorite(exercise.id, !exercise.isFavorite)
        }
    }

    /** Sync from API — called once at app start if local DB is empty. */
    fun syncIfEmpty() {
        viewModelScope.launch {
            if (uiState.value.exercises.isEmpty()) {
                exerciseRepository.syncExercisesFromApi()
            }
        }
    }
}
