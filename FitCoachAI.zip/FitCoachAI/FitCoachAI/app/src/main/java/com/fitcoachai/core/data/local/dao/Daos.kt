package com.fitcoachai.core.data.local.dao

import androidx.room.*
import com.fitcoachai.core.data.local.entity.*
import com.fitcoachai.domain.model.WorkoutStatus
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

// ─── User Profile DAO ─────────────────────────────────────────────────────────

@Dao
interface UserProfileDao {
    @Query("SELECT * FROM user_profiles WHERE uid = :uid")
    suspend fun getProfile(uid: String): UserProfileEntity?

    @Upsert
    suspend fun upsertProfile(profile: UserProfileEntity)

    @Query("DELETE FROM user_profiles WHERE uid = :uid")
    suspend fun deleteProfile(uid: String)
}

// ─── Exercise DAO ─────────────────────────────────────────────────────────────

@Dao
interface ExerciseDao {
    /** Observe full exercise list — reactive Flow triggers recomposition automatically. */
    @Query("SELECT * FROM exercises ORDER BY name ASC")
    fun observeAll(): Flow<List<ExerciseEntity>>

    @Query("SELECT * FROM exercises WHERE id = :id")
    suspend fun getById(id: String): ExerciseEntity?

    /** Full-text search by name (LIKE is fine for local exercise sets <5000 rows). */
    @Query("SELECT * FROM exercises WHERE name LIKE '%' || :query || '%' ORDER BY name ASC")
    fun search(query: String): Flow<List<ExerciseEntity>>

    @Query("SELECT * FROM exercises WHERE isFavorite = 1 ORDER BY name ASC")
    fun observeFavorites(): Flow<List<ExerciseEntity>>

    @Query("UPDATE exercises SET isFavorite = :favorite WHERE id = :id")
    suspend fun toggleFavorite(id: String, favorite: Boolean)

    @Upsert
    suspend fun upsertAll(exercises: List<ExerciseEntity>)

    @Upsert
    suspend fun upsert(exercise: ExerciseEntity)
}

// ─── Workout DAO ──────────────────────────────────────────────────────────────

@Dao
interface WorkoutDao {
    @Query("SELECT * FROM workouts ORDER BY scheduledDate DESC, completedAt DESC")
    fun observeAll(): Flow<List<WorkoutEntity>>

    @Query("SELECT * FROM workouts WHERE isTemplate = 0 AND status = 'COMPLETED' ORDER BY completedAt DESC")
    fun observeCompleted(): Flow<List<WorkoutEntity>>

    @Query("SELECT * FROM workouts WHERE scheduledDate = :date")
    fun observeForDate(date: LocalDate): Flow<List<WorkoutEntity>>

    @Query("SELECT * FROM workouts WHERE id = :id")
    suspend fun getById(id: String): WorkoutEntity?

    @Query("SELECT * FROM workouts WHERE isTemplate = 1 ORDER BY name ASC")
    fun observeTemplates(): Flow<List<WorkoutEntity>>

    @Upsert
    suspend fun upsert(workout: WorkoutEntity)

    @Delete
    suspend fun delete(workout: WorkoutEntity)

    @Query("UPDATE workouts SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: String, status: WorkoutStatus)

    /**
     * Returns number of completed workouts in the last [days] days.
     * Used for streak calculations and weekly summary cards.
     */
    @Query("""
        SELECT COUNT(*) FROM workouts 
        WHERE status = 'COMPLETED' 
          AND completedAt >= :since
    """)
    suspend fun countCompletedSince(since: String): Int
}

// ─── Workout-Exercise Join DAO ────────────────────────────────────────────────

@Dao
interface WorkoutExerciseDao {
    @Query("SELECT * FROM workout_exercises WHERE workoutId = :workoutId ORDER BY orderIndex ASC")
    suspend fun getForWorkout(workoutId: String): List<WorkoutExerciseEntity>

    @Query("SELECT * FROM workout_exercises WHERE workoutId = :workoutId ORDER BY orderIndex ASC")
    fun observeForWorkout(workoutId: String): Flow<List<WorkoutExerciseEntity>>

    @Upsert
    suspend fun upsertAll(entries: List<WorkoutExerciseEntity>)

    @Query("DELETE FROM workout_exercises WHERE workoutId = :workoutId")
    suspend fun deleteAllForWorkout(workoutId: String)

    @Delete
    suspend fun delete(entry: WorkoutExerciseEntity)
}

// ─── Body Stats DAO ──────────────────────────────────────────────────────────

@Dao
interface BodyStatDao {
    @Query("SELECT * FROM body_stats ORDER BY date DESC")
    fun observeAll(): Flow<List<BodyStatEntity>>

    @Query("SELECT * FROM body_stats ORDER BY date DESC LIMIT 1")
    suspend fun getLatest(): BodyStatEntity?

    @Query("SELECT * FROM body_stats WHERE date >= :since ORDER BY date ASC")
    fun observeSince(since: LocalDate): Flow<List<BodyStatEntity>>

    @Upsert
    suspend fun upsert(stat: BodyStatEntity)

    @Delete
    suspend fun delete(stat: BodyStatEntity)
}

// ─── Chat Messages DAO ───────────────────────────────────────────────────────

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun observeAll(): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(message: ChatMessageEntity)

    @Query("DELETE FROM chat_messages")
    suspend fun clearAll()
}
