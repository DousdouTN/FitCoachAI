package com.fitcoachai.core.data.repository

import com.fitcoachai.core.data.local.entity.*
import com.fitcoachai.core.data.remote.dto.ExerciseApiDto
import com.fitcoachai.domain.model.*
import java.time.LocalDateTime

// ─── Entity ↔ Domain Mappers ──────────────────────────────────────────────────
// Pure mapping functions. No business logic here.

fun UserProfileEntity.toDomain() = UserProfile(
    uid                = uid,
    email              = email,
    displayName        = displayName,
    photoUrl           = photoUrl,
    age                = age,
    weightKg           = weightKg,
    heightCm           = heightCm,
    goal               = goal,
    experience         = experience,
    availableEquipment = availableEquipment,
    workoutsPerWeek    = workoutsPerWeek,
    createdAt          = createdAt
)

fun UserProfile.toEntity() = UserProfileEntity(
    uid                = uid,
    email              = email,
    displayName        = displayName,
    photoUrl           = photoUrl,
    age                = age,
    weightKg           = weightKg,
    heightCm           = heightCm,
    goal               = goal,
    experience         = experience,
    availableEquipment = availableEquipment,
    workoutsPerWeek    = workoutsPerWeek,
    createdAt          = createdAt
)

fun ExerciseEntity.toDomain() = Exercise(
    id               = id,
    name             = name,
    targetMuscles    = targetMuscles,
    secondaryMuscles = secondaryMuscles,
    equipment        = equipment,
    difficulty       = difficulty,
    instructions     = instructions,
    tips             = tips,
    animationUrl     = animationUrl,
    thumbnailUrl     = thumbnailUrl,
    videoUrl         = videoUrl,
    isFavorite       = isFavorite,
    category         = category
)

fun Exercise.toEntity() = ExerciseEntity(
    id               = id,
    name             = name,
    targetMuscles    = targetMuscles,
    secondaryMuscles = secondaryMuscles,
    equipment        = equipment,
    difficulty       = difficulty,
    instructions     = instructions,
    tips             = tips,
    animationUrl     = animationUrl,
    thumbnailUrl     = thumbnailUrl,
    videoUrl         = videoUrl,
    isFavorite       = isFavorite,
    category         = category
)

fun WorkoutEntity.toDomain(exercises: List<WorkoutExercise> = emptyList()) = Workout(
    id                         = id,
    name                       = name,
    description                = description,
    exercises                  = exercises,
    estimatedDurationMinutes   = estimatedDurationMinutes,
    status                     = status,
    scheduledDate              = scheduledDate,
    completedAt                = completedAt,
    totalVolumeKg              = totalVolumeKg,
    notes                      = notes,
    isTemplate                 = isTemplate,
    createdByAI                = createdByAI,
    programId                  = programId
)

fun Workout.toEntity() = WorkoutEntity(
    id                       = id,
    name                     = name,
    description              = description,
    estimatedDurationMinutes = estimatedDurationMinutes,
    status                   = status,
    scheduledDate            = scheduledDate,
    completedAt              = completedAt,
    totalVolumeKg            = totalVolumeKg,
    notes                    = notes,
    isTemplate               = isTemplate,
    createdByAI              = createdByAI,
    programId                = programId
)

fun BodyStatEntity.toDomain() = BodyStat(
    id             = id,
    weightKg       = weightKg,
    bodyFatPercent = bodyFatPercent,
    muscleMassKg   = muscleMassKg,
    date           = date,
    notes          = notes
)

fun BodyStat.toEntity() = BodyStatEntity(
    id             = id,
    weightKg       = weightKg,
    bodyFatPercent = bodyFatPercent,
    muscleMassKg   = muscleMassKg,
    date           = date,
    notes          = notes
)

fun ChatMessageEntity.toDomain() = ChatMessage(
    id          = id,
    content     = content,
    isFromUser  = isFromUser,
    timestamp   = timestamp
)

fun ChatMessage.toEntity() = ChatMessageEntity(
    id         = id,
    content    = content,
    isFromUser = isFromUser,
    timestamp  = timestamp
)

// ─── API DTO → Entity Mapper ──────────────────────────────────────────────────

/**
 * Maps ExerciseDB API response to our local entity.
 * The API uses string identifiers we map to our enums defensively.
 */
fun ExerciseApiDto.toEntity(): ExerciseEntity {
    fun mapMuscle(name: String) = runCatching {
        MuscleGroup.valueOf(name.uppercase().replace(" ", "_"))
    }.getOrDefault(MuscleGroup.FULL_BODY)

    fun mapEquipment(name: String) = runCatching {
        Equipment.valueOf(name.uppercase().replace(" ", "_").replace("-", "_"))
    }.getOrDefault(Equipment.NONE)

    return ExerciseEntity(
        id               = id,
        name             = name,
        targetMuscles    = listOf(mapMuscle(targetMuscle)),
        secondaryMuscles = secondaryMuscles.map { mapMuscle(it) },
        equipment        = mapEquipment(equipment),
        difficulty       = Difficulty.INTERMEDIATE, // API doesn't provide difficulty
        instructions     = instructions,
        tips             = emptyList(),
        animationUrl     = animationUrl,
        thumbnailUrl     = animationUrl,  // Use GIF as thumbnail fallback
        videoUrl         = null,
        isFavorite       = false,
        category         = bodyPart
    )
}
