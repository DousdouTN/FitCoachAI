package com.fitcoachai.core.utils

import okhttp3.Interceptor
import okhttp3.Response

/**
 * Injects `Authorization: Bearer <token>` header for OpenAI requests.
 *
 * The API key is pulled from BuildConfig at compile time.
 * In production, consider fetching it from your own backend to avoid
 * embedding the key in the APK (even under ProGuard).
 */
class AuthInterceptor(private val apiKey: String) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request().newBuilder()
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .build()
        return chain.proceed(request)
    }
}

/**
 * Injects RapidAPI authentication headers for the ExerciseDB service.
 */
class ExerciseApiInterceptor(
    private val apiKey: String,
    private val apiHost: String = "exercisedb.p.rapidapi.com"
) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request().newBuilder()
            .addHeader("X-RapidAPI-Key", apiKey)
            .addHeader("X-RapidAPI-Host", apiHost)
            .build()
        return chain.proceed(request)
    }
}

// ─── Result Wrapper ───────────────────────────────────────────────────────────

/**
 * Generic sealed result class — replaces exception propagation across layers.
 * ViewModels consume [Result] to drive UI state without try/catch.
 */
sealed class Result<out T> {
    data class Success<T>(val data: T) : Result<T>()
    data class Error(val message: String, val cause: Throwable? = null) : Result<Nothing>()
    data object Loading : Result<Nothing>()
}

/** Convenience extensions */
val <T> Result<T>.isSuccess get() = this is Result.Success
val <T> Result<T>.isLoading get() = this is Result.Loading
val <T> Result<T>.isError   get() = this is Result.Error

inline fun <T, R> Result<T>.mapSuccess(transform: (T) -> R): Result<R> = when (this) {
    is Result.Success -> Result.Success(transform(data))
    is Result.Error   -> this
    is Result.Loading -> Result.Loading
}

// ─── Constants ────────────────────────────────────────────────────────────────

object Constants {
    // System prompt that defines the AI coach persona
    const val AI_SYSTEM_PROMPT = """
You are FitCoach AI, a world-class personal fitness coach with expertise in:
- Exercise science, biomechanics, and progressive overload principles
- Nutrition and recovery optimization
- Personalized programming for all fitness levels

Your responses should be:
- Concise, practical, and evidence-based
- Encouraging but honest about realistic expectations
- Safety-conscious (always mention form cues and injury prevention)
- Structured with clear sections when generating workout plans

When generating workout plans, format them as:
Day X — [Focus]:
  Exercise Name: X sets × X reps @ X kg | Rest: Xs
  
Always include warm-up and cool-down recommendations.
"""

    // Prompt templates for structured AI outputs
    fun workoutPlanPrompt(
        goal: String,
        experience: String,
        equipment: String,
        daysPerWeek: Int,
        durationWeeks: Int
    ) = """
Generate a $durationWeeks-week, $daysPerWeek-day/week workout plan for:
- Goal: $goal
- Experience: $experience  
- Equipment: $equipment

Include: exercise name, sets, reps, rest time, and brief form notes.
Format each day clearly. Add progression notes for each week.
""".trimIndent()
}
