package com.fitcoachai.presentation.navigation

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.fitcoachai.presentation.auth.AuthScreen
import com.fitcoachai.presentation.chat.ChatScreen
import com.fitcoachai.presentation.exercise.ExerciseLibraryScreen
import com.fitcoachai.presentation.home.HomeScreen
import com.fitcoachai.presentation.progress.ProgressScreen
import com.fitcoachai.presentation.theme.FitCoachColors
import com.fitcoachai.presentation.workout.WorkoutBuilderScreen
import com.fitcoachai.presentation.workout.WorkoutSessionScreen

// ─── Navigation Routes ─────────────────────────────────────────────────────────

sealed class Route(val path: String) {
    // Auth flow
    object Auth : Route("auth")

    // Main destinations (bottom nav)
    object Home       : Route("home")
    object Workouts   : Route("workouts")
    object Exercises  : Route("exercises")
    object Progress   : Route("progress")
    object Chat       : Route("chat")

    // Detail screens
    object WorkoutBuilder : Route("workout_builder?workoutId={workoutId}") {
        fun create(workoutId: String? = null) =
            if (workoutId != null) "workout_builder?workoutId=$workoutId" else "workout_builder"
    }
    object WorkoutSession : Route("workout_session/{workoutId}") {
        fun create(workoutId: String) = "workout_session/$workoutId"
    }
}

// ─── Bottom Nav Items ─────────────────────────────────────────────────────────

data class BottomNavItem(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

val bottomNavItems = listOf(
    BottomNavItem(Route.Home.path,      "Home",      Icons.Filled.Home,         Icons.Outlined.Home),
    BottomNavItem(Route.Workouts.path,  "Workouts",  Icons.Filled.FitnessCenter,Icons.Outlined.FitnessCenter),
    BottomNavItem(Route.Exercises.path, "Exercises", Icons.Filled.MenuBook,     Icons.Outlined.MenuBook),
    BottomNavItem(Route.Progress.path,  "Progress",  Icons.Filled.BarChart,     Icons.Outlined.BarChart),
    BottomNavItem(Route.Chat.path,      "AI Coach",  Icons.Filled.AutoAwesome,  Icons.Outlined.AutoAwesome)
)

// ─── Root Nav Host ────────────────────────────────────────────────────────────

@Composable
fun FitCoachNavHost(
    isLoggedIn: Boolean,
    navController: NavHostController = rememberNavController()
) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute   = backStackEntry?.destination?.route

    val showBottomBar = currentRoute in bottomNavItems.map { it.route }

    Scaffold(
        containerColor  = FitCoachColors.Background,
        bottomBar = {
            if (showBottomBar) {
                FitCoachBottomNav(navController = navController, currentRoute = currentRoute)
            }
        }
    ) { paddingValues ->
        NavHost(
            navController    = navController,
            startDestination = if (isLoggedIn) Route.Home.path else Route.Auth.path,
            modifier         = Modifier.padding(bottom = if (showBottomBar) paddingValues.calculateBottomPadding() else 0.dp),
            enterTransition  = { fadeIn() + slideInHorizontally() },
            exitTransition   = { fadeOut() },
            popEnterTransition = { fadeIn() },
            popExitTransition  = { fadeOut() + slideOutHorizontally() }
        ) {
            // ── Auth ───────────────────────────────────────────────────────
            composable(Route.Auth.path) {
                AuthScreen(
                    onAuthenticated = {
                        navController.navigate(Route.Home.path) {
                            popUpTo(Route.Auth.path) { inclusive = true }
                        }
                    }
                )
            }

            // ── Home ───────────────────────────────────────────────────────
            composable(Route.Home.path) {
                HomeScreen(
                    onWorkoutClick      = { id -> navController.navigate(Route.WorkoutBuilder.create(id)) },
                    onStartWorkoutClick = { id -> navController.navigate(Route.WorkoutSession.create(id)) },
                    onChatClick         = { navController.navigate(Route.Chat.path) }
                )
            }

            // ── Workouts ───────────────────────────────────────────────────
            composable(Route.Workouts.path) {
                WorkoutBuilderScreen(
                    onAddExercise = { navController.navigate(Route.Exercises.path) },
                    onSaved       = { navController.popBackStack() }
                )
            }

            // ── Exercise Library ───────────────────────────────────────────
            composable(Route.Exercises.path) {
                ExerciseLibraryScreen(
                    onExerciseClick = { /* Navigate to detail */ }
                )
            }

            // ── Progress ───────────────────────────────────────────────────
            composable(Route.Progress.path) {
                ProgressScreen()
            }

            // ── AI Chat ────────────────────────────────────────────────────
            composable(Route.Chat.path) {
                ChatScreen()
            }

            // ── Workout Builder (edit mode) ────────────────────────────────
            composable(
                route     = Route.WorkoutBuilder.path,
                arguments = listOf(navArgument("workoutId") {
                    type     = NavType.StringType
                    nullable = true
                    defaultValue = null
                })
            ) {
                WorkoutBuilderScreen(
                    onAddExercise = { navController.navigate(Route.Exercises.path) },
                    onSaved       = { navController.popBackStack() }
                )
            }

            // ── Active Session ─────────────────────────────────────────────
            composable(
                route     = Route.WorkoutSession.path,
                arguments = listOf(navArgument("workoutId") { type = NavType.StringType })
            ) { entry ->
                val workoutId = entry.arguments?.getString("workoutId") ?: return@composable
                WorkoutSessionScreen(
                    workoutId  = workoutId,
                    onComplete = { navController.navigate(Route.Progress.path) { popUpTo(Route.Home.path) } }
                )
            }
        }
    }
}

// ─── Bottom Navigation Bar ────────────────────────────────────────────────────

@Composable
fun FitCoachBottomNav(
    navController: NavController,
    currentRoute: String?
) {
    NavigationBar(
        containerColor = FitCoachColors.Surface,
        tonalElevation = 0.dp
    ) {
        val navBackStack by navController.currentBackStackEntryAsState()
        val currentDestination = navBackStack?.destination

        bottomNavItems.forEach { item ->
            val isSelected = currentDestination?.hierarchy?.any { it.route == item.route } == true
            NavigationBarItem(
                selected  = isSelected,
                onClick   = {
                    navController.navigate(item.route) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState    = true
                    }
                },
                icon = {
                    Icon(
                        imageVector        = if (isSelected) item.selectedIcon else item.unselectedIcon,
                        contentDescription = item.label
                    )
                },
                label = {
                    Text(
                        text  = item.label,
                        style = MaterialTheme.typography.labelSmall
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor   = FitCoachColors.Primary,
                    selectedTextColor   = FitCoachColors.Primary,
                    unselectedIconColor = FitCoachColors.TextSecondary,
                    unselectedTextColor = FitCoachColors.TextSecondary,
                    indicatorColor      = FitCoachColors.Primary.copy(alpha = 0.12f)
                )
            )
        }
    }
}
