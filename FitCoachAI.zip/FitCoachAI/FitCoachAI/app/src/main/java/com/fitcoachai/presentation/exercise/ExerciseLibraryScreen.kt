package com.fitcoachai.presentation.exercise

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.fitcoachai.domain.model.*
import com.fitcoachai.presentation.components.ExerciseCard
import com.fitcoachai.presentation.components.ShimmerBox
import com.fitcoachai.presentation.theme.FitCoachColors

/**
 * Exercise Library screen.
 *
 * Features:
 * - Live search with debounce
 * - Chip filters (muscle group, equipment, difficulty)
 * - Favorites toggle
 * - GIF thumbnail previews via Coil
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExerciseLibraryScreen(
    onExerciseClick: (exerciseId: String) -> Unit,
    viewModel: ExerciseViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    // Sync from API if DB is empty (first launch)
    LaunchedEffect(Unit) { viewModel.syncIfEmpty() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(FitCoachColors.Background)
    ) {

        // ── Top Bar ────────────────────────────────────────────────────────
        Row(
            modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 56.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text     = "Exercise Library",
                style    = MaterialTheme.typography.headlineSmall,
                color    = FitCoachColors.TextPrimary,
                modifier = Modifier.weight(1f)
            )
            IconButton(
                onClick = viewModel::toggleFavoritesOnly
            ) {
                Icon(
                    imageVector        = if (state.showFavoritesOnly) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Favorites",
                    tint               = if (state.showFavoritesOnly) FitCoachColors.HeartRed else FitCoachColors.TextSecondary
                )
            }
        }

        // ── Search Bar ─────────────────────────────────────────────────────
        SearchBar(
            query          = state.searchQuery,
            onQueryChange  = viewModel::onSearchQueryChange,
            onSearch       = {},
            active         = false,
            onActiveChange = {},
            placeholder    = { Text("Search exercises...", color = FitCoachColors.TextMuted) },
            leadingIcon    = { Icon(Icons.Default.Search, contentDescription = null, tint = FitCoachColors.TextSecondary) },
            trailingIcon   = if (state.searchQuery.isNotBlank()) {{
                IconButton(onClick = { viewModel.onSearchQueryChange("") }) {
                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = FitCoachColors.TextSecondary)
                }
            }} else null,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            colors = SearchBarDefaults.colors(
                containerColor      = FitCoachColors.SurfaceContainer,
                inputFieldColors    = TextFieldDefaults.colors(
                    focusedTextColor    = FitCoachColors.TextPrimary,
                    unfocusedTextColor  = FitCoachColors.TextPrimary,
                    cursorColor         = FitCoachColors.Primary
                )
            )
        ) {}

        Spacer(modifier = Modifier.height(8.dp))

        // ── Muscle Group Chips ─────────────────────────────────────────────
        LazyRow(
            contentPadding        = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FilterChip(
                    selected = state.selectedMuscleGroup == null,
                    onClick  = { viewModel.onMuscleGroupFilter(null) },
                    label    = { Text("All") },
                    colors   = filterChipColors()
                )
            }
            items(MuscleGroup.values()) { mg ->
                FilterChip(
                    selected = state.selectedMuscleGroup == mg,
                    onClick  = { viewModel.onMuscleGroupFilter(if (state.selectedMuscleGroup == mg) null else mg) },
                    label    = { Text(mg.displayName) },
                    colors   = filterChipColors()
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // ── Equipment Chips ────────────────────────────────────────────────
        LazyRow(
            contentPadding        = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(Equipment.values()) { eq ->
                FilterChip(
                    selected = state.selectedEquipment == eq,
                    onClick  = { viewModel.onEquipmentFilter(if (state.selectedEquipment == eq) null else eq) },
                    label    = { Text(eq.displayName) },
                    colors   = filterChipColors()
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // ── Count label ────────────────────────────────────────────────────
        Text(
            text     = "${state.exercises.size} exercises",
            style    = MaterialTheme.typography.labelMedium,
            color    = FitCoachColors.TextSecondary,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
        )

        // ── Exercise List ──────────────────────────────────────────────────
        LazyColumn(
            contentPadding        = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement   = Arrangement.spacedBy(10.dp)
        ) {
            if (state.isLoading) {
                items(6) {
                    ShimmerBox(modifier = Modifier.fillMaxWidth().height(90.dp))
                }
            } else {
                items(state.exercises, key = { it.id }) { exercise ->
                    ExerciseCard(
                        exercise        = exercise,
                        onClick         = { onExerciseClick(exercise.id) },
                        onFavoriteClick = { viewModel.toggleFavorite(exercise) }
                    )
                }
            }
        }
    }
}

@Composable
private fun filterChipColors() = FilterChipDefaults.filterChipColors(
    selectedContainerColor = FitCoachColors.Primary.copy(alpha = 0.15f),
    selectedLabelColor     = FitCoachColors.Primary,
    labelColor             = FitCoachColors.TextSecondary,
    containerColor         = FitCoachColors.SurfaceContainer
)
