package com.fitcoachai.presentation.chat

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.fitcoachai.domain.model.ChatMessage
import com.fitcoachai.presentation.components.ShimmerBox
import com.fitcoachai.presentation.theme.FitCoachColors
import kotlinx.coroutines.launch
import java.time.format.DateTimeFormatter

/**
 * AI Chat screen — conversational interface with the FitCoach AI.
 *
 * Design:
 * - User messages: right-aligned teal bubble
 * - AI messages: left-aligned dark card with AI icon
 * - Typing indicator: animated shimmer dots
 * - Quick prompt chips above input for common queries
 */
@Composable
fun ChatScreen(
    viewModel: ChatViewModel = hiltViewModel()
) {
    val state   by viewModel.uiState.collectAsState()
    val scope   = rememberCoroutineScope()
    val listState = rememberLazyListState()

    // Auto-scroll to bottom on new messages
    LaunchedEffect(state.messages.size, state.isAiTyping) {
        if (state.messages.isNotEmpty() || state.isAiTyping) {
            scope.launch { listState.animateScrollToItem(Int.MAX_VALUE) }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(FitCoachColors.Background)
    ) {

        // ── Top Bar ────────────────────────────────────────────────────────
        Row(
            modifier = Modifier.padding(start = 20.dp, end = 12.dp, top = 56.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(FitCoachColors.Secondary.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector        = Icons.Default.AutoAwesome,
                    contentDescription = "AI",
                    tint               = FitCoachColors.Secondary,
                    modifier           = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text  = "FitCoach AI",
                    style = MaterialTheme.typography.titleMedium,
                    color = FitCoachColors.TextPrimary
                )
                Text(
                    text  = if (state.isAiTyping) "Typing..." else "Online",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (state.isAiTyping) FitCoachColors.Primary else FitCoachColors.TextSecondary
                )
            }
            IconButton(onClick = viewModel::clearHistory) {
                Icon(Icons.Default.DeleteSweep, contentDescription = "Clear", tint = FitCoachColors.TextSecondary)
            }
        }

        HorizontalDivider(color = FitCoachColors.Divider)

        // ── Message List ───────────────────────────────────────────────────
        LazyColumn(
            modifier            = Modifier.weight(1f),
            state               = listState,
            contentPadding      = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Welcome message when empty
            if (state.messages.isEmpty() && !state.isAiTyping) {
                item { WelcomeCard() }
            }

            items(state.messages, key = { it.id }) { message ->
                AnimatedVisibility(
                    visible  = true,
                    enter    = fadeIn() + slideInVertically(initialOffsetY = { it / 2 })
                ) {
                    MessageBubble(message = message)
                }
            }

            // Typing indicator
            if (state.isAiTyping) {
                item { TypingIndicator() }
            }
        }

        // ── Quick Prompts ──────────────────────────────────────────────────
        if (state.messages.isEmpty()) {
            LazyRow(
                contentPadding        = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(QUICK_PROMPTS) { prompt ->
                    SuggestionChip(
                        onClick = { viewModel.sendQuickPrompt(prompt) },
                        label   = { Text(prompt, maxLines = 1) },
                        colors  = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = FitCoachColors.SurfaceContainer,
                            labelColor     = FitCoachColors.TextSecondary
                        )
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        // ── Input Row ──────────────────────────────────────────────────────
        ChatInputRow(
            text     = state.inputText,
            onChange = viewModel::onInputChange,
            onSend   = viewModel::sendMessage,
            enabled  = !state.isAiTyping
        )
    }
}

// ─── Message Bubble ───────────────────────────────────────────────────────────

@Composable
private fun MessageBubble(message: ChatMessage) {
    val timeFormat = DateTimeFormatter.ofPattern("HH:mm")

    Row(
        modifier              = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isFromUser) Arrangement.End else Arrangement.Start,
        verticalAlignment     = Alignment.Bottom
    ) {
        if (!message.isFromUser) {
            // AI avatar
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(FitCoachColors.Secondary.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector        = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint               = FitCoachColors.Secondary,
                    modifier           = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Column(
            horizontalAlignment = if (message.isFromUser) Alignment.End else Alignment.Start,
            modifier            = Modifier.widthIn(max = 280.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(
                        RoundedCornerShape(
                            topStart    = 16.dp,
                            topEnd      = 16.dp,
                            bottomEnd   = if (message.isFromUser) 4.dp else 16.dp,
                            bottomStart = if (message.isFromUser) 16.dp else 4.dp
                        )
                    )
                    .background(
                        if (message.isFromUser)
                            Brush.horizontalGradient(listOf(FitCoachColors.Primary, Color(android.graphics.Color.parseColor("#00B2FF"))))
                        else
                            Brush.linearGradient(listOf(FitCoachColors.Surface, FitCoachColors.SurfaceVariant))
                    )
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text(
                    text  = message.content,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (message.isFromUser) FitCoachColors.OnPrimary else FitCoachColors.TextPrimary
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text  = message.timestamp.format(timeFormat),
                style = MaterialTheme.typography.labelSmall,
                color = FitCoachColors.TextMuted
            )
        }
    }
}

// ─── Typing Indicator ─────────────────────────────────────────────────────────

@Composable
private fun TypingIndicator() {
    Row(
        modifier          = Modifier.padding(start = 40.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(FitCoachColors.Surface)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                repeat(3) { index ->
                    ShimmerBox(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(RoundedCornerShape(50))
                    )
                }
            }
        }
    }
}

// ─── Chat Input Row ───────────────────────────────────────────────────────────

@Composable
private fun ChatInputRow(
    text: String,
    onChange: (String) -> Unit,
    onSend: () -> Unit,
    enabled: Boolean
) {
    Row(
        modifier          = Modifier
            .fillMaxWidth()
            .background(FitCoachColors.Surface)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .navigationBarsPadding(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedTextField(
            value         = text,
            onValueChange = onChange,
            placeholder   = { Text("Ask your coach...", color = FitCoachColors.TextMuted) },
            modifier      = Modifier.weight(1f),
            maxLines      = 4,
            colors        = OutlinedTextFieldDefaults.colors(
                focusedBorderColor   = FitCoachColors.Primary,
                unfocusedBorderColor = FitCoachColors.Divider,
                focusedTextColor     = FitCoachColors.TextPrimary,
                unfocusedTextColor   = FitCoachColors.TextPrimary,
                cursorColor          = FitCoachColors.Primary
            ),
            shape = RoundedCornerShape(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        IconButton(
            onClick  = onSend,
            enabled  = enabled && text.isNotBlank(),
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(
                    if (enabled && text.isNotBlank()) FitCoachColors.Primary
                    else FitCoachColors.SurfaceVariant
                )
        ) {
            Icon(
                imageVector        = Icons.Default.Send,
                contentDescription = "Send",
                tint               = if (enabled && text.isNotBlank()) FitCoachColors.OnPrimary
                                     else FitCoachColors.TextMuted
            )
        }
    }
}

// ─── Welcome Card ─────────────────────────────────────────────────────────────

@Composable
private fun WelcomeCard() {
    Card(
        colors = CardDefaults.cardColors(containerColor = FitCoachColors.SurfaceVariant),
        shape  = MaterialTheme.shapes.large,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector        = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint               = FitCoachColors.Secondary,
                modifier           = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text  = "Hi! I'm your FitCoach AI",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = FitCoachColors.TextPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text  = "I can create personalized workout plans, explain exercises, optimize your nutrition, and track your progress. What would you like help with?",
                style = MaterialTheme.typography.bodySmall,
                color = FitCoachColors.TextSecondary
            )
        }
    }
}

// Workaround for Color parsing in Compose gradient
private val Color = androidx.compose.ui.graphics.Color
