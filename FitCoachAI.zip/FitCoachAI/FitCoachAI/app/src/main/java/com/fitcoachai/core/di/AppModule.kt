package com.fitcoachai.core.di

import android.content.Context
import androidx.room.Room
import com.fitcoachai.BuildConfig
import com.fitcoachai.core.data.local.FitCoachDatabase
import com.fitcoachai.core.data.local.dao.*
import com.fitcoachai.core.data.remote.api.ExerciseDbService
import com.fitcoachai.core.data.remote.api.OpenAiService
import com.fitcoachai.core.utils.AuthInterceptor
import com.fitcoachai.core.utils.ExerciseApiInterceptor
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Named
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    // ─── Moshi ────────────────────────────────────────────────────────────────

    @Provides @Singleton
    fun provideMoshi(): Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    // ─── OkHttp clients ───────────────────────────────────────────────────────

    @Provides @Singleton @Named("openai")
    fun provideOpenAiOkHttp(): OkHttpClient = OkHttpClient.Builder()
        .addInterceptor(AuthInterceptor(BuildConfig.OPENAI_API_KEY))
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BODY
                    else HttpLoggingInterceptor.Level.NONE
        })
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)   // AI responses can take time
        .build()

    @Provides @Singleton @Named("exercisedb")
    fun provideExerciseDbOkHttp(): OkHttpClient = OkHttpClient.Builder()
        .addInterceptor(ExerciseApiInterceptor(
            apiKey  = BuildConfig.EXERCISE_DB_API_KEY,  // Add to local.properties
            apiHost = "exercisedb.p.rapidapi.com"
        ))
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.HEADERS
                    else HttpLoggingInterceptor.Level.NONE
        })
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    // ─── Retrofit services ────────────────────────────────────────────────────

    @Provides @Singleton
    fun provideOpenAiService(@Named("openai") client: OkHttpClient, moshi: Moshi): OpenAiService =
        Retrofit.Builder()
            .baseUrl(BuildConfig.OPENAI_BASE_URL)
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(OpenAiService::class.java)

    @Provides @Singleton
    fun provideExerciseDbService(@Named("exercisedb") client: OkHttpClient, moshi: Moshi): ExerciseDbService =
        Retrofit.Builder()
            .baseUrl("https://exercisedb.p.rapidapi.com/")
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(ExerciseDbService::class.java)

    // ─── Room Database ────────────────────────────────────────────────────────

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext context: Context): FitCoachDatabase =
        Room.databaseBuilder(context, FitCoachDatabase::class.java, FitCoachDatabase.DB_NAME)
            .fallbackToDestructiveMigration()   // Replace with proper migrations in production
            .build()

    @Provides fun provideUserProfileDao(db: FitCoachDatabase): UserProfileDao = db.userProfileDao()
    @Provides fun provideExerciseDao(db: FitCoachDatabase): ExerciseDao = db.exerciseDao()
    @Provides fun provideWorkoutDao(db: FitCoachDatabase): WorkoutDao = db.workoutDao()
    @Provides fun provideWorkoutExerciseDao(db: FitCoachDatabase): WorkoutExerciseDao = db.workoutExerciseDao()
    @Provides fun provideBodyStatDao(db: FitCoachDatabase): BodyStatDao = db.bodyStatDao()
    @Provides fun provideChatMessageDao(db: FitCoachDatabase): ChatMessageDao = db.chatMessageDao()

    // ─── Firebase ─────────────────────────────────────────────────────────────

    @Provides @Singleton
    fun provideFirebaseAuth(): FirebaseAuth = FirebaseAuth.getInstance()

    @Provides @Singleton
    fun provideFirestore(): FirebaseFirestore = FirebaseFirestore.getInstance()
}
