package com.fitcoachai.core.data.repository

import com.fitcoachai.core.data.local.dao.*
import com.fitcoachai.core.data.remote.api.ExerciseDbService
import com.fitcoachai.core.data.remote.api.OpenAiService
import com.fitcoachai.core.data.remote.dto.ChatRequest
import com.fitcoachai.core.data.remote.dto.MessageDto
import com.fitcoachai.core.utils.Constants
import com.fitcoachai.core.utils.Result
import com.fitcoachai.domain.model.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

// ─── Auth Repository ─────────────────────────────────────────────────────────

@Singleton
class AuthRepository @Inject constructor(
    private val auth: FirebaseAuth
) {
    val currentUser get() = auth.currentUser

    val isLoggedIn get() = auth.currentUser != null

    /**
     * Email/password sign-in. Returns Result wrapping Firebase User uid.
     */
    suspend fun signInWithEmail(email: String, password: String): Result<String> = runCatching {
        val result = auth.signInWithEmailAndPassword(email, password).await()
        Result.Success(result.user!!.uid)
    }.getOrElse { Result.Error(it.message ?: "Sign-in failed", it) }

    /**
     * Email/password registration.
     */
    suspend fun registerWithEmail(email: String, password: String): Result<String> = runCatching {
        val result = auth.createUserWithEmailAndPassword(email, password).await()
        Result.Success(result.user!!.uid)
    }.getOrElse { Result.Error(it.message ?: "Registration failed", it) }

    /**
     * Google Sign-In — pass the idToken obtained from the Google Sign-In intent.
     */
    suspend fun signInWithGoogle(idToken: String): Result<String> = runCatching {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        val result = auth.signInWithCredential(credential).await()
        Result.Success(result.user!!.uid)
    }.getOrElse { Result.Error(it.message ?: "Google sign-in failed", it) }

    fun signOut() = auth.signOut()
}

// ─── User Profile Repository ──────────────────────────────────────────────────

@Singleton
class UserRepository @Inject constructor(
    private val userProfileDao: UserProfileDao,
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth
) {
    private val uid get() = auth.currentUser?.uid ?: error("User not authenticated")

    suspend fun getProfile(): UserProfile? =
        userProfileDao.getProfile(uid)?.toDomain()

    /**
     * Save profile locally AND push to Firestore for cross-device sync.
     */
    suspend fun saveProfile(profile: UserProfile): Result<Unit> = runCatching {
        userProfileDao.upsertProfile(profile.toEntity())
        firestore.collection("users").document(uid)
            .set(profile)
            .await()
        Result.Success(Unit)
    }.getOrElse { Result.Error(it.message ?: "Profile save failed", it) }
}

// ─── Exercise Repository ──────────────────────────────────────────────────────

@Singleton
class ExerciseRepository @Inject constructor(
    private val exerciseDao: ExerciseDao,
    private val exerciseDbService: ExerciseDbService
) {
    /** Observe local exercise list — emits on every DB change. */
    fun observeExercises(): Flow<List<Exercise>> =
        exerciseDao.observeAll().map { it.map { e -> e.toDomain() } }

    fun observeFavorites(): Flow<List<Exercise>> =
        exerciseDao.observeFavorites().map { it.map { e -> e.toDomain() } }

    fun searchExercises(query: String): Flow<List<Exercise>> =
        exerciseDao.search(query).map { it.map { e -> e.toDomain() } }

    suspend fun getExerciseById(id: String): Exercise? =
        exerciseDao.getById(id)?.toDomain()

    suspend fun toggleFavorite(exerciseId: String, isFavorite: Boolean) =
        exerciseDao.toggleFavorite(exerciseId, isFavorite)

    /**
     * Fetch exercises from the remote API and cache them locally.
     * Network-first with local fallback — called once on first app launch.
     */
    suspend fun syncExercisesFromApi(): Result<Unit> = runCatching {
        val response = exerciseDbService.getExercises(limit = 500)
        if (response.isSuccessful) {
            val entities = response.body()?.map { it.toEntity() } ?: emptyList()
            exerciseDao.upsertAll(entities)
            Result.Success(Unit)
        } else {
            Result.Error("API error ${response.code()}: ${response.message()}")
        }
    }.getOrElse { Result.Error(it.message ?: "Sync failed", it) }
}

// ─── Workout Repository ───────────────────────────────────────────────────────

@Singleton
class WorkoutRepository @Inject constructor(
    private val workoutDao: WorkoutDao,
    private val workoutExerciseDao: WorkoutExerciseDao,
    private val exerciseDao: ExerciseDao,
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth
) {
    private val uid get() = auth.currentUser?.uid ?: ""

    fun observeAllWorkouts(): Flow<List<Workout>> =
        workoutDao.observeAll().map { workouts ->
            workouts.map { it.toDomain() }  // Exercises loaded lazily for list views
        }

    fun observeCompletedWorkouts(): Flow<List<Workout>> =
        workoutDao.observeCompleted().map { it.map { w -> w.toDomain() } }

    fun observeTemplates(): Flow<List<Workout>> =
        workoutDao.observeTemplates().map { it.map { w -> w.toDomain() } }

    /**
     * Load a full workout with all exercises. Joins WorkoutEntity,
     * WorkoutExerciseEntity, and ExerciseEntity tables.
     */
    suspend fun getWorkoutWithExercises(workoutId: String): Workout? {
        val workoutEntity = workoutDao.getById(workoutId) ?: return null
        val joinRows = workoutExerciseDao.getForWorkout(workoutId)
        val exercises = joinRows.mapNotNull { join ->
            val exercise = exerciseDao.getById(join.exerciseId) ?: return@mapNotNull null
            WorkoutExercise(
                exercise   = exercise.toDomain(),
                sets       = join.sets,
                notes      = join.notes,
                orderIndex = join.orderIndex
            )
        }.sortedBy { it.orderIndex }
        return workoutEntity.toDomain(exercises)
    }

    /**
     * Save or update a workout and all its exercise associations.
     * Wrapped in a transaction-like pattern via sequential upserts.
     */
    suspend fun saveWorkout(workout: Workout): Result<String> = runCatching {
        workoutDao.upsert(workout.toEntity())
        // Refresh exercise associations
        workoutExerciseDao.deleteAllForWorkout(workout.id)
        val joins = workout.exercises.mapIndexed { index, we ->
            WorkoutExerciseEntity(
                workoutId  = workout.id,
                exerciseId = we.exercise.id,
                sets       = we.sets,
                notes      = we.notes,
                orderIndex = index
            )
        }
        workoutExerciseDao.upsertAll(joins)
        // Sync to Firestore (best-effort — local is source of truth)
        if (uid.isNotBlank()) {
            firestore.collection("users").document(uid)
                .collection("workouts").document(workout.id)
                .set(workout.toEntity())
        }
        Result.Success(workout.id)
    }.getOrElse { Result.Error(it.message ?: "Save failed", it) }

    suspend fun deleteWorkout(workout: Workout): Result<Unit> = runCatching {
        workoutDao.delete(workout.toEntity())
        Result.Success(Unit)
    }.getOrElse { Result.Error(it.message ?: "Delete failed", it) }

    suspend fun updateStatus(workoutId: String, status: WorkoutStatus) =
        workoutDao.updateStatus(workoutId, status)

    /**
     * Build a new workout entity with a fresh UUID.
     */
    fun createBlankWorkout(name: String = "New Workout") = Workout(
        id        = UUID.randomUUID().toString(),
        name      = name,
        exercises = emptyList()
    )
}

// ─── Body Stats Repository ────────────────────────────────────────────────────

@Singleton
class BodyStatRepository @Inject constructor(
    private val bodyStatDao: BodyStatDao,
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth
) {
    private val uid get() = auth.currentUser?.uid ?: ""

    fun observeAllStats(): Flow<List<BodyStat>> =
        bodyStatDao.observeAll().map { it.map { e -> e.toDomain() } }

    fun observeStatsSince(date: LocalDate): Flow<List<BodyStat>> =
        bodyStatDao.observeSince(date).map { it.map { e -> e.toDomain() } }

    suspend fun getLatest(): BodyStat? = bodyStatDao.getLatest()?.toDomain()

    suspend fun saveStat(stat: BodyStat): Result<Unit> = runCatching {
        bodyStatDao.upsert(stat.toEntity())
        Result.Success(Unit)
    }.getOrElse { Result.Error(it.message ?: "Save failed", it) }
}

// ─── AI Chat Repository ───────────────────────────────────────────────────────

@Singleton
class AiChatRepository @Inject constructor(
    private val openAiService: OpenAiService,
    private val chatMessageDao: ChatMessageDao
) {
    fun observeMessages(): Flow<List<ChatMessage>> =
        chatMessageDao.observeAll().map { it.map { e -> e.toDomain() } }

    suspend fun saveMessage(message: ChatMessage) =
        chatMessageDao.insert(message.toEntity())

    suspend fun clearHistory() = chatMessageDao.clearAll()

    /**
     * Send a conversation to OpenAI and return the assistant's reply.
     *
     * @param conversationHistory  Full chat history for context window.
     * @param systemPrompt         Coach persona injected as system message.
     */
    suspend fun sendMessage(
        conversationHistory: List<ChatMessage>,
        systemPrompt: String = Constants.AI_SYSTEM_PROMPT
    ): Result<String> = runCatching {
        val messages = buildList {
            add(MessageDto(role = "system", content = systemPrompt))
            conversationHistory.forEach { msg ->
                add(MessageDto(
                    role    = if (msg.isFromUser) "user" else "assistant",
                    content = msg.content
                ))
            }
        }

        val response = openAiService.createChatCompletion(
            ChatRequest(messages = messages)
        )

        if (response.isSuccessful) {
            val reply = response.body()
                ?.choices
                ?.firstOrNull()
                ?.message
                ?.content
                ?: "No response received."
            Result.Success(reply)
        } else {
            Result.Error("API error ${response.code()}: ${response.message()}")
        }
    }.getOrElse { Result.Error(it.message ?: "Network error", it) }

    /**
     * Generate a structured workout plan via OpenAI.
     * Uses a templated prompt for consistent JSON-style output.
     */
    suspend fun generateWorkoutPlan(
        goal: String,
        experience: String,
        equipment: String,
        daysPerWeek: Int = 4,
        durationWeeks: Int = 8
    ): Result<String> {
        val prompt = Constants.workoutPlanPrompt(goal, experience, equipment, daysPerWeek, durationWeeks)
        val messages = listOf(
            MessageDto("system", Constants.AI_SYSTEM_PROMPT),
            MessageDto("user", prompt)
        )
        return runCatching {
            val response = openAiService.createChatCompletion(ChatRequest(messages = messages, maxTokens = 3000))
            if (response.isSuccessful) {
                Result.Success(response.body()?.choices?.firstOrNull()?.message?.content ?: "")
            } else {
                Result.Error("API error ${response.code()}")
            }
        }.getOrElse { Result.Error(it.message ?: "Generation failed", it) }
    }
}
