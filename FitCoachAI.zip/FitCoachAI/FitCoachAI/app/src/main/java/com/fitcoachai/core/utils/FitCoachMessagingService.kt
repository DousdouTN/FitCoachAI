package com.fitcoachai.core.utils

import android.app.NotificationManager
import androidx.core.app.NotificationCompat
import com.fitcoachai.FitCoachApplication
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Firebase Cloud Messaging service.
 *
 * Handles push notifications sent from Firebase or your backend server.
 * Token refresh is automatically stored for server-side targeting.
 *
 * Push message payload expected format:
 * {
 *   "notification": { "title": "...", "body": "..." },
 *   "data": { "type": "workout_reminder" | "progress" | "ai_message" }
 * }
 */
class FitCoachMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        // In production: POST token to your backend or save to Firestore
        // so you can send targeted push notifications per user.
        // Example: saveTokenToFirestore(token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)

        val title = message.notification?.title ?: "FitCoach AI"
        val body  = message.notification?.body  ?: return

        val channelId = when (message.data["type"]) {
            "progress" -> FitCoachApplication.CHANNEL_PROGRESS
            else       -> FitCoachApplication.CHANNEL_WORKOUT_REMINDER
        }

        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(System.currentTimeMillis().toInt(), notification)
    }
}
