package com.fitcoachai.core.utils

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.fitcoachai.FitCoachApplication
import com.fitcoachai.MainActivity
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

/**
 * WorkManager worker that fires a daily workout reminder notification.
 *
 * Scheduling example (call from HomeViewModel or settings screen):
 *
 *   WorkoutReminderWorker.schedule(context, hourOfDay = 8, minute = 0)
 *
 * The worker is Hilt-injected via @HiltWorker so it can access repositories.
 */
@HiltWorker
class WorkoutReminderWorker @AssistedInject constructor(
    @Assisted private val context: Context,
    @Assisted workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        val message = inputData.getString(KEY_MESSAGE) ?: "Time to crush today's workout!"

        val notificationManager = context.getSystemService(NotificationManager::class.java)

        val tapIntent = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(context, FitCoachApplication.CHANNEL_WORKOUT_REMINDER)
            .setSmallIcon(android.R.drawable.ic_dialog_info)  // Replace with custom drawable
            .setContentTitle("FitCoach AI")
            .setContentText(message)
            .setAutoCancel(true)
            .setContentIntent(tapIntent)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        notificationManager.notify(NOTIFICATION_ID, notification)
        return Result.success()
    }

    companion object {
        private const val KEY_MESSAGE     = "message"
        private const val NOTIFICATION_ID = 1001
        private const val WORK_NAME       = "workout_reminder"

        /**
         * Schedule a repeating daily reminder at the given time.
         * Uses [PeriodicWorkRequest] with a 24-hour interval.
         *
         * Call [cancelReminder] to remove it.
         */
        fun schedule(context: Context, message: String = "Time to work out!") {
            val data = workDataOf(KEY_MESSAGE to message)
            val request = PeriodicWorkRequestBuilder<WorkoutReminderWorker>(24, TimeUnit.HOURS)
                .setInputData(data)
                .setConstraints(Constraints.Builder().build())
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
        }

        fun cancelReminder(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
