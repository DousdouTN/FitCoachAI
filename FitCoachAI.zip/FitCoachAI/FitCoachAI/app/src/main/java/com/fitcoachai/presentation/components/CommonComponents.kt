package com.fitcoachai.presentation.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.fitcoachai.domain.model.Exercise
import com.fitcoachai.presentation.theme.FitCoachColors

// ─── Gradient Button ──────────────────────────────────────────────────────────

/**
 * Primary CTA button with the brand teal gradient.
 * Used for "Start Workout", "Send", "Save" etc.
 */
@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val gradient = Brush.horizontalGradient(
        colors = listOf(FitCoachColors.Primary, Color(0xFF00B2FF))
    )
    Box(
        modifier = modifier
            .height(52.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (enabled) gradient else Brush.horizontalGradient(
                listOf(FitCoachColors.TextMuted, FitCoachColors.TextMuted)
            ))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text  = text,
            style = MaterialTheme.typography.labelLarge,
            color = if (enabled) FitCoachColors.OnPrimary else FitCoachColors.TextMuted
        )
    }
}

// ─── Stat Card ────────────────────────────────────────────────────────────────

/**
 * Small KPI card for the home dashboard (workouts this week, streak, volume, etc.)
 */
@Composable
fun StatCard(
    label: String,
    value: String,
    unit: String = "",
    icon: ImageVector? = null,
    accentColor: Color = FitCoachColors.Primary,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors   = CardDefaults.cardColors(containerColor = FitCoachColors.Surface),
        shape    = MaterialTheme.shapes.medium
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint   = accentColor,
                    modifier = Modifier.size(20.dp)
                )
            }
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text  = value,
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
                    color = FitCoachColors.TextPrimary
                )
                if (unit.isNotBlank()) {
                    Text(
                        text     = unit,
                        style    = MaterialTheme.typography.bodySmall,
                        color    = FitCoachColors.TextSecondary,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }
            }
            Text(
                text  = label,
                style = MaterialTheme.typography.labelSmall,
                color = FitCoachColors.TextSecondary
            )
        }
    }
}

// ─── Exercise Card ────────────────────────────────────────────────────────────

@Composable
fun ExerciseCard(
    exercise: Exercise,
    onClick: () -> Unit,
    onFavoriteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = FitCoachColors.Surface),
        shape  = MaterialTheme.shapes.medium
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Exercise GIF thumbnail
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(MaterialTheme.shapes.small)
                    .background(FitCoachColors.SurfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                if (exercise.thumbnailUrl != null) {
                    AsyncImage(
                        model             = exercise.thumbnailUrl,
                        contentDescription = exercise.name,
                        contentScale      = ContentScale.Crop,
                        modifier          = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector        = Icons.Default.FitnessCenter,
                        contentDescription = null,
                        tint               = FitCoachColors.TextMuted,
                        modifier           = Modifier.size(32.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text  = exercise.name,
                    style = MaterialTheme.typography.titleSmall,
                    color = FitCoachColors.TextPrimary,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text  = exercise.targetMuscles.joinToString { it.displayName },
                    style = MaterialTheme.typography.bodySmall,
                    color = FitCoachColors.TextSecondary,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    DifficultyChip(label = exercise.difficulty.displayName)
                    EquipmentChip(label = exercise.equipment.displayName)
                }
            }
        }
    }
}

// ─── Chips ────────────────────────────────────────────────────────────────────

@Composable
fun DifficultyChip(label: String) {
    val color = when (label.lowercase()) {
        "beginner"     -> Color(0xFF00C853)
        "intermediate" -> FitCoachColors.Warning
        "advanced"     -> FitCoachColors.Error
        else           -> FitCoachColors.TextSecondary
    }
    Surface(
        shape = MaterialTheme.shapes.extraSmall,
        color = color.copy(alpha = 0.15f)
    ) {
        Text(
            text     = label,
            style    = MaterialTheme.typography.labelSmall,
            color    = color,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun EquipmentChip(label: String) {
    Surface(
        shape = MaterialTheme.shapes.extraSmall,
        color = FitCoachColors.SurfaceContainer
    ) {
        Text(
            text     = label,
            style    = MaterialTheme.typography.labelSmall,
            color    = FitCoachColors.TextSecondary,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
        )
    }
}

// ─── Shimmer Loading Skeleton ─────────────────────────────────────────────────

/**
 * Animated shimmer box for loading states.
 * Width and height are defined by the caller modifier.
 */
@Composable
fun ShimmerBox(modifier: Modifier = Modifier) {
    val shimmerColors = listOf(
        FitCoachColors.Surface,
        FitCoachColors.SurfaceVariant,
        FitCoachColors.Surface
    )
    val transition = rememberInfiniteTransition(label = "shimmer")
    val translateAnim by transition.animateFloat(
        initialValue   = 0f,
        targetValue    = 1000f,
        animationSpec  = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmerAnim"
    )
    Box(
        modifier = modifier
            .clip(MaterialTheme.shapes.small)
            .background(
                Brush.linearGradient(
                    colors = shimmerColors,
                    start  = Offset(translateAnim - 1000f, 0f),
                    end    = Offset(translateAnim, 0f)
                )
            )
    )
}

// ─── Rest Timer Ring ──────────────────────────────────────────────────────────

@Composable
fun RestTimerRing(
    remainingSeconds: Int,
    totalSeconds: Int,
    modifier: Modifier = Modifier
) {
    val progress = if (totalSeconds > 0) remainingSeconds.toFloat() / totalSeconds else 0f
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        CircularProgressIndicator(
            progress     = { progress },
            modifier     = Modifier.fillMaxSize(),
            color        = FitCoachColors.Primary,
            trackColor   = FitCoachColors.SurfaceVariant,
            strokeWidth  = 6.dp
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text  = String.format("%02d:%02d", remainingSeconds / 60, remainingSeconds % 60),
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                color = FitCoachColors.TextPrimary
            )
            Text(
                text  = "REST",
                style = MaterialTheme.typography.labelSmall,
                color = FitCoachColors.TextSecondary
            )
        }
    }
}
