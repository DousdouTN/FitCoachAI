package com.fitcoachai

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

/**
 * Application class — required for Hilt DI initialization.
 *
 * Also:
 * - Sets up WorkManager with Hilt integration (for notification workers)
 * - Creates notification channels for workout reminders and progress alerts
 */
@HiltAndroidApp
class FitCoachApplication : Application(), Configuration.Provider {

    @Inject
    lateinit var workerFactory: HiltWorkerFactory

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            // Workout reminder channel
            NotificationChannel(
                CHANNEL_WORKOUT_REMINDER,
                "Workout Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Daily workout schedule reminders"
                manager.createNotificationChannel(this)
            }

            // Progress milestone channel
            NotificationChannel(
                CHANNEL_PROGRESS,
                "Progress Milestones",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Personal records and progress updates"
                manager.createNotificationChannel(this)
            }
        }
    }

    companion object {
        const val CHANNEL_WORKOUT_REMINDER = "workout_reminders"
        const val CHANNEL_PROGRESS         = "progress_milestones"
    }
}
