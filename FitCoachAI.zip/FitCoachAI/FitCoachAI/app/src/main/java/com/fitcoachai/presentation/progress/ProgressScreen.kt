package com.fitcoachai.presentation.progress

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.fitcoachai.domain.model.BodyStat
import com.fitcoachai.presentation.components.GradientButton
import com.fitcoachai.presentation.components.StatCard
import com.fitcoachai.presentation.theme.FitCoachColors
import java.time.format.DateTimeFormatter

/**
 * Progress tracking screen.
 *
 * Sections:
 * 1. Period selector (1W / 1M / 3M / All)
 * 2. Weight trend chart (Vico)
 * 3. Body stat history list
 * 4. Workout volume chart
 * 5. Add body stat FAB → dialog
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressScreen(
    viewModel: ProgressViewModel = hiltViewModel()
) {
    val state   by viewModel.uiState.collectAsState()
    val stats   by viewModel.filteredStats.collectAsState()

    Scaffold(
        containerColor = FitCoachColors.Background,
        floatingActionButton = {
            FloatingActionButton(
                onClick          = viewModel::showAddStatDialog,
                containerColor   = FitCoachColors.Primary,
                contentColor     = FitCoachColors.OnPrimary,
                shape            = MaterialTheme.shapes.large
            ) {
                Icon(Icons.Default.Add, contentDescription = "Log body stat")
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier       = Modifier.fillMaxSize().padding(paddingValues),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {

            // ── Header ─────────────────────────────────────────────────────
            item {
                Text(
                    text     = "Progress",
                    style    = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color    = FitCoachColors.TextPrimary,
                    modifier = Modifier.padding(start = 20.dp, top = 56.dp, bottom = 16.dp)
                )
            }

            // ── Period Selector ────────────────────────────────────────────
            item {
                Row(
                    modifier              = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ProgressPeriod.values().forEach { period ->
                        FilterChip(
                            selected = state.selectedPeriod == period,
                            onClick  = { viewModel.selectPeriod(period) },
                            label    = { Text(period.label) },
                            colors   = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = FitCoachColors.Primary.copy(alpha = 0.2f),
                                selectedLabelColor     = FitCoachColors.Primary,
                                containerColor         = FitCoachColors.SurfaceContainer,
                                labelColor             = FitCoachColors.TextSecondary
                            )
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // ── Weight Chart ───────────────────────────────────────────────
            item {
                WeightChartCard(
                    stats    = stats,
                    modifier = Modifier.padding(horizontal = 20.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            // ── Summary Stats ──────────────────────────────────────────────
            item {
                Row(
                    modifier              = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val latest = stats.firstOrNull()
                    val oldest = stats.lastOrNull()
                    val change = if (latest != null && oldest != null && latest.id != oldest.id)
                        latest.weightKg - oldest.weightKg else null

                    StatCard(
                        label      = "Current",
                        value      = latest?.weightKg?.let { String.format("%.1f", it) } ?: "--",
                        unit       = "kg",
                        icon       = Icons.Default.MonitorWeight,
                        modifier   = Modifier.weight(1f)
                    )
                    StatCard(
                        label      = "Change",
                        value      = change?.let { "${if (it >= 0) "+" else ""}${String.format("%.1f", it)}" } ?: "--",
                        unit       = "kg",
                        icon       = Icons.Default.TrendingUp,
                        accentColor = when {
                            change == null     -> FitCoachColors.TextSecondary
                            change < 0         -> FitCoachColors.Success
                            else               -> FitCoachColors.Warning
                        },
                        modifier   = Modifier.weight(1f)
                    )
                    StatCard(
                        label      = "Workouts",
                        value      = "${state.completedWorkouts.size}",
                        icon       = Icons.Default.FitnessCenter,
                        modifier   = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
            }

            // ── Stat History ───────────────────────────────────────────────
            item {
                Text(
                    text     = "Body Measurements",
                    style    = MaterialTheme.typography.titleMedium,
                    color    = FitCoachColors.TextPrimary,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
            }

            if (stats.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                        colors   = CardDefaults.cardColors(containerColor = FitCoachColors.Surface),
                        shape    = MaterialTheme.shapes.medium
                    ) {
                        Column(
                            modifier            = Modifier.fillMaxWidth().padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector        = Icons.Default.MonitorWeight,
                                contentDescription = null,
                                tint               = FitCoachColors.TextMuted,
                                modifier           = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No data yet", style = MaterialTheme.typography.bodyMedium, color = FitCoachColors.TextSecondary)
                            Text("Tap + to log your first measurement", style = MaterialTheme.typography.bodySmall, color = FitCoachColors.TextMuted)
                        }
                    }
                }
            } else {
                items(stats) { stat ->
                    BodyStatRow(
                        stat     = stat,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }

    // ── Add Stat Dialog ────────────────────────────────────────────────────
    if (state.showAddStatDialog) {
        AddBodyStatDialog(
            weightInput = state.newWeightInput,
            fatInput    = state.newBodyFatInput,
            isSaving    = state.isSavingBodyStat,
            onWeightChange = viewModel::onWeightInput,
            onFatChange    = viewModel::onBodyFatInput,
            onSave         = viewModel::saveBodyStat,
            onDismiss      = viewModel::hideAddStatDialog
        )
    }
}

// ─── Sub-composables ──────────────────────────────────────────────────────────

@Composable
private fun WeightChartCard(
    stats: List<BodyStat>,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors   = CardDefaults.cardColors(containerColor = FitCoachColors.Surface),
        shape    = MaterialTheme.shapes.medium
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text  = "Weight Trend",
                style = MaterialTheme.typography.titleSmall,
                color = FitCoachColors.TextPrimary
            )
            Spacer(modifier = Modifier.height(12.dp))

            if (stats.size < 2) {
                Box(
                    modifier            = Modifier.fillMaxWidth().height(120.dp),
                    contentAlignment    = Alignment.Center
                ) {
                    Text(
                        text  = "Log at least 2 measurements to see a chart",
                        style = MaterialTheme.typography.bodySmall,
                        color = FitCoachColors.TextMuted
                    )
                }
            } else {
                // ── Vico Chart ────────────────────────────────────────────
                // NOTE: In a real project, wire up Vico's CartesianChartHost here.
                // Data: stats.map { it.date to it.weightKg } as LineCartesianLayerModel.
                // This placeholder box represents the chart area.
                Box(
                    modifier         = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .background(FitCoachColors.SurfaceVariant, MaterialTheme.shapes.small),
                    contentAlignment = Alignment.Center
                ) {
                    // ─── Vico integration point ────────────────────────────
                    // import com.patrykandpatrick.vico.compose.cartesian.*
                    // import com.patrykandpatrick.vico.compose.common.*
                    //
                    // val model = remember(stats) {
                    //     CartesianChartModelProducer.build {
                    //         lineSeries { series(stats.map { it.weightKg }) }
                    //     }
                    // }
                    // CartesianChartHost(
                    //     chart = rememberCartesianChart(
                    //         rememberLineCartesianLayer(
                    //             LineCartesianLayer.LineProvider.series(
                    //                 rememberLine(fill = remember { Fill(FitCoachColors.Primary) })
                    //             )
                    //         )
                    //     ),
                    //     modelProducer = model,
                    //     modifier = Modifier.fillMaxSize()
                    // )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.ShowChart, contentDescription = null, tint = FitCoachColors.Primary, modifier = Modifier.size(32.dp))
                        Text(
                            text  = "${stats.size} data points — chart renders via Vico",
                            style = MaterialTheme.typography.labelSmall,
                            color = FitCoachColors.TextSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BodyStatRow(stat: BodyStat, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors   = CardDefaults.cardColors(containerColor = FitCoachColors.Surface),
        shape    = MaterialTheme.shapes.small
    ) {
        Row(
            modifier          = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text  = stat.date.format(DateTimeFormatter.ofPattern("MMM dd, yyyy")),
                    style = MaterialTheme.typography.bodyMedium,
                    color = FitCoachColors.TextPrimary
                )
                if (stat.bodyFatPercent != null) {
                    Text(
                        text  = "Body fat: ${String.format("%.1f", stat.bodyFatPercent)}%",
                        style = MaterialTheme.typography.bodySmall,
                        color = FitCoachColors.TextSecondary
                    )
                }
            }
            Text(
                text  = "${String.format("%.1f", stat.weightKg)} kg",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                color = FitCoachColors.Primary
            )
        }
    }
}

@Composable
private fun AddBodyStatDialog(
    weightInput: String,
    fatInput: String,
    isSaving: Boolean,
    onWeightChange: (String) -> Unit,
    onFatChange: (String) -> Unit,
    onSave: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest  = onDismiss,
        containerColor    = FitCoachColors.Surface,
        title = {
            Text("Log Body Measurement", color = FitCoachColors.TextPrimary)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value         = weightInput,
                    onValueChange = onWeightChange,
                    label         = { Text("Weight (kg)") },
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                        keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal
                    ),
                    singleLine = true,
                    colors     = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor   = FitCoachColors.Primary,
                        unfocusedBorderColor = FitCoachColors.Divider,
                        focusedTextColor     = FitCoachColors.TextPrimary,
                        unfocusedTextColor   = FitCoachColors.TextPrimary
                    )
                )
                OutlinedTextField(
                    value         = fatInput,
                    onValueChange = onFatChange,
                    label         = { Text("Body Fat % (optional)") },
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                        keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal
                    ),
                    singleLine = true,
                    colors     = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor   = FitCoachColors.Primary,
                        unfocusedBorderColor = FitCoachColors.Divider,
                        focusedTextColor     = FitCoachColors.TextPrimary,
                        unfocusedTextColor   = FitCoachColors.TextPrimary
                    )
                )
            }
        },
        confirmButton = {
            GradientButton(
                text    = if (isSaving) "Saving..." else "Save",
                onClick = onSave,
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth()
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = FitCoachColors.TextSecondary)
            }
        }
    )
}
