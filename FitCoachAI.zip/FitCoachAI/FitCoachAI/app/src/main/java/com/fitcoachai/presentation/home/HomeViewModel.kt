package com.fitcoachai.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fitcoachai.core.data.repository.*
import com.fitcoachai.domain.model.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

data class HomeUiState(
    val isLoading: Boolean = true,
    val userProfile: UserProfile? = null,
    val todayWorkouts: List<Workout> = emptyList(),
    val weeklySummary: WeeklySummary? = null,
    val recentExercises: List<Exercise> = emptyList(),
    val latestBodyStat: BodyStat? = null,
    val error: String? = null
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val userRepository: UserRepository,
    private val workoutRepository: WorkoutRepository,
    private val bodyStatRepository: BodyStatRepository,
    private val aiChatRepository: AiChatRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        loadDashboard()
    }

    private fun loadDashboard() {
        viewModelScope.launch {
            // Combine multiple reactive streams into one cohesive UI state
            combine(
                workoutRepository.observeAllWorkouts(),
                bodyStatRepository.observeAllStats()
            ) { workouts, stats ->
                val today = LocalDate.now()
                val todayWorkouts = workouts.filter { it.scheduledDate == today }
                val lastSevenDays = workouts.filter {
                    it.status == WorkoutStatus.COMPLETED &&
                    it.completedAt?.toLocalDate()?.isAfter(today.minusDays(7)) == true
                }
                val summary = WeeklySummary(
                    weekStartDate       = today.minusDays(6),
                    workoutsCompleted   = lastSevenDays.size,
                    workoutsPlanned     = workouts.count { it.scheduledDate?.isAfter(today.minusDays(1)) == true },
                    totalVolumeKg       = lastSevenDays.sumOf { it.totalVolumeKg.toDouble() }.toFloat(),
                    totalDurationMinutes= lastSevenDays.sumOf { it.estimatedDurationMinutes },
                    streakDays          = calculateStreak(workouts)
                )
                _uiState.update { state ->
                    state.copy(
                        isLoading      = false,
                        todayWorkouts  = todayWorkouts,
                        weeklySummary  = summary,
                        latestBodyStat = stats.firstOrNull()
                    )
                }
            }.collect()
        }

        viewModelScope.launch {
            _uiState.update { it.copy(userProfile = userRepository.getProfile()) }
        }
    }

    /**
     * Calculates consecutive days with a completed workout.
     * Streak resets if a day was missed.
     */
    private fun calculateStreak(workouts: List<Workout>): Int {
        var streak = 0
        var date = LocalDate.now()
        val completedDates = workouts
            .filter { it.status == WorkoutStatus.COMPLETED }
            .mapNotNull { it.completedAt?.toLocalDate() }
            .toSet()

        while (completedDates.contains(date)) {
            streak++
            date = date.minusDays(1)
        }
        return streak
    }

    fun generateAiWorkoutSuggestion() {
        val profile = _uiState.value.userProfile ?: return
        viewModelScope.launch {
            aiChatRepository.generateWorkoutPlan(
                goal        = profile.goal.displayName,
                experience  = profile.experience.displayName,
                equipment   = profile.availableEquipment.joinToString { it.displayName },
                daysPerWeek = profile.workoutsPerWeek
            )
        }
    }
}
